# MidiToQwertyAndr (без NDK, Java 8)

## Совместимость
- Gradle 6.7.1 + AGP 4.2.2
- Java 8
- **Без NDK** (логика нот на Kotlin)

## Функции
1. Overlay (SYSTEM_ALERT_WINDOW)
2. Shizuku → «рут права дали» / «рута нет»
3. Показ последней MIDI-ноты

## Сборка
```bash
chmod +x gradlew
./gradlew assembleDebug
```

package com.miditoqwertyMyx.android

import org.json.JSONArray
import org.json.JSONObject

/** One screen point mapped to a MIDI note (absolute pixels). */
data class NotePoint(
    val note: Int,
    var x: Float,
    var y: Float,
    var enabled: Boolean = true
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("note", note)
        put("x", x.toDouble())
        put("y", y.toDouble())
        put("enabled", enabled)
    }

    companion object {
        fun fromJson(o: JSONObject) = NotePoint(
            note = o.getInt("note"),
            x = o.getDouble("x").toFloat(),
            y = o.getDouble("y").toFloat(),
            enabled = o.optBoolean("enabled", true)
        )
    }
}

/** Named set of note → point mappings. */
data class ClickPreset(
    var id: String,
    var name: String,
    val points: MutableMap<Int, NotePoint> = mutableMapOf()
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        val arr = JSONArray()
        points.values.forEach { arr.put(it.toJson()) }
        put("points", arr)
    }

    companion object {
        fun fromJson(o: JSONObject): ClickPreset {
            val p = ClickPreset(id = o.getString("id"), name = o.getString("name"))
            val arr = o.optJSONArray("points") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val np = NotePoint.fromJson(arr.getJSONObject(i))
                p.points[np.note] = np
            }
            return p
        }

        fun createEmpty(name: String) =
            ClickPreset(id = "preset_${System.currentTimeMillis()}", name = name)
    }
}

package com.miditoqwertyMyx.android

/**
 * USB gadget phone-as-keyboard-for-PC was experimental and needs root + /dev/hidg0.
 * Disabled in this build (keep class so MainActivity compiles).
 */
object HidGadget {
    var available: Boolean = false
        private set

    fun init(tryEnableConfig: Boolean = true): String {
        available = false
        return "USB-HID: off (use Shizuku inject on phone)"
    }

    fun tapKey(key: String): Boolean = false
}

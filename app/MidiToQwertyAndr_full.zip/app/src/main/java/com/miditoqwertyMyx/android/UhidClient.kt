package com.miditoqwertyMyx.android

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import android.util.Log
import rikka.shizuku.Shizuku

object UhidClient {
    private const val TAG = "UhidClient"

    @Volatile
    private var service: IUhidService? = null

    @Volatile
    var bound = false
        private set

    private val args by lazy {
        Shizuku.UserServiceArgs(ComponentName("com.miditoqwertyMyx.android", UhidService::class.java.name))
            .daemon(false)
            .processNameSuffix("uhid")
            .debuggable(false)
            .version(1)
    }

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            if (binder == null || !binder.pingBinder()) {
                Log.e(TAG, "bad binder")
                return
            }
            service = IUhidService.Stub.asInterface(binder)
            bound = true
            try {
                val ok = service?.createDevices() == true
                Log.i(TAG, "createDevices=$ok status=${service?.status()}")
            } catch (e: Exception) {
                Log.e(TAG, "createDevices failed", e)
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            bound = false
            service = null
            Log.w(TAG, "service disconnected")
        }
    }

    fun start(context: Context): Boolean {
        if (!Shizuku.pingBinder()) return false
        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) return false
        return try {
            if (bound) return true
            Shizuku.bindUserService(args, connection)
            true
        } catch (e: Exception) {
            Log.e(TAG, "bindUserService failed", e)
            false
        }
    }

    fun stop() {
        try {
            service?.destroyDevices()
        } catch (_: Exception) {}
        try {
            Shizuku.unbindUserService(args, connection, true)
        } catch (_: Exception) {}
        bound = false
        service = null
    }

    fun tapKey(key: String): Boolean {
        return try {
            service?.tapKey(key) == true
        } catch (e: Exception) {
            Log.e(TAG, "tapKey", e)
            false
        }
    }

    fun mouseMove(dx: Int, dy: Int): Boolean {
        return try {
            service?.mouseMove(dx, dy) == true
        } catch (e: Exception) {
            false
        }
    }

    fun enablePcModeHint(): Boolean {
        // several relative moves so system may show pointer
        var ok = false
        for (i in 0 until 5) {
            if (mouseMove(3, 2)) ok = true
            try { Thread.sleep(16) } catch (_: Exception) {}
            if (mouseMove(-2, 1)) ok = true
        }
        return ok
    }

    fun status(): String {
        return try {
            service?.status() ?: "not bound"
        } catch (e: Exception) {
            e.message ?: "error"
        }
    }

    fun isUhidActive(): Boolean {
        return try {
            service?.isActive() == true
        } catch (_: Exception) {
            false
        }
    }
}

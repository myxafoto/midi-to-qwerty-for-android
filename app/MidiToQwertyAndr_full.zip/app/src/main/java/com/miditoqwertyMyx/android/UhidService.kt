package com.miditoqwertyMyx.android

import android.util.Log

/**
 * Runs inside Shizuku process (shell uid) so /dev/uhid is accessible.
 * Primary constructor required by Kotlin + Shizuku UserService.
 */
class UhidService() : IUhidService.Stub() {

    companion object {
        private const val TAG = "UhidService"
        private const val MOD_CTRL = 0x01
        private const val MOD_SHIFT = 0x02

        private val CHAR_TO_HID = mapOf(
            'a' to 0x04, 'b' to 0x05, 'c' to 0x06, 'd' to 0x07, 'e' to 0x08,
            'f' to 0x09, 'g' to 0x0A, 'h' to 0x0B, 'i' to 0x0C, 'j' to 0x0D,
            'k' to 0x0E, 'l' to 0x0F, 'm' to 0x10, 'n' to 0x11, 'o' to 0x12,
            'p' to 0x13, 'q' to 0x14, 'r' to 0x15, 's' to 0x16, 't' to 0x17,
            'u' to 0x18, 'v' to 0x19, 'w' to 0x1A, 'x' to 0x1B, 'y' to 0x1C,
            'z' to 0x1D,
            '1' to 0x1E, '2' to 0x1F, '3' to 0x20, '4' to 0x21, '5' to 0x22,
            '6' to 0x23, '7' to 0x24, '8' to 0x25, '9' to 0x26, '0' to 0x27
        )
    }

    private var keyboard: UhidDevice? = null
    private var mouse: UhidDevice? = null
    private val lock = Any()

    init {
        Log.i(TAG, "UhidService created in uid=${android.os.Process.myUid()}")
    }

    override fun createDevices(): Boolean {
        synchronized(lock) {
            destroyDevicesLocked()
            val kb = UhidDevice("MidiQwertyKeyboard", UhidDevice.KEYBOARD_DESC)
            val ms = UhidDevice("MidiQwertyMouse", UhidDevice.MOUSE_DESC)
            val okKb = kb.open()
            val okMs = ms.open()
            if (okKb) keyboard = kb else kb.close()
            if (okMs) mouse = ms else ms.close()
            Log.i(TAG, "createDevices kb=$okKb mouse=$okMs uid=${android.os.Process.myUid()}")
            return okKb
        }
    }

    override fun destroyDevices() {
        synchronized(lock) { destroyDevicesLocked() }
    }

    private fun destroyDevicesLocked() {
        keyboard?.close()
        mouse?.close()
        keyboard = null
        mouse = null
    }

    override fun isActive(): Boolean = synchronized(lock) { keyboard?.isOpen == true }

    override fun status(): String {
        val uid = android.os.Process.myUid()
        val kb = keyboard?.isOpen == true
        val ms = mouse?.isOpen == true
        return "uid=$uid kb=$kb mouse=$ms"
    }

    override fun tapKey(key: String): Boolean {
        val resolved = resolve(key) ?: return false
        val mod = resolved.first
        val hid = resolved.second
        synchronized(lock) {
            val kb = keyboard ?: return false
            val press = byteArrayOf(mod.toByte(), 0, hid.toByte(), 0, 0, 0, 0, 0)
            val release = byteArrayOf(0, 0, 0, 0, 0, 0, 0, 0)
            return kb.writeInput(press) && kb.writeInput(release)
        }
    }

    override fun mouseMove(dx: Int, dy: Int): Boolean {
        synchronized(lock) {
            val ms = mouse ?: return false
            val report = byteArrayOf(
                0,
                dx.coerceIn(-127, 127).toByte(),
                dy.coerceIn(-127, 127).toByte()
            )
            return ms.writeInput(report)
        }
    }

    private fun resolve(key: String): Pair<Int, Int>? {
        if (key.startsWith("ctrl_")) {
            val ch = key.removePrefix("ctrl_").lowercase().firstOrNull() ?: return null
            val hid = CHAR_TO_HID[ch] ?: return null
            return MOD_CTRL to hid
        }
        if (key.length != 1) return null
        val c = key[0]
        return when {
            c in 'A'..'Z' -> {
                val hid = CHAR_TO_HID[c.lowercaseChar()] ?: return null
                MOD_SHIFT to hid
            }
            c in 'a'..'z' || c in '0'..'9' -> {
                val hid = CHAR_TO_HID[c] ?: return null
                0 to hid
            }
            c == '!' -> MOD_SHIFT to 0x1E
            c == '@' -> MOD_SHIFT to 0x1F
            c == '#' -> MOD_SHIFT to 0x20
            c == '$' -> MOD_SHIFT to 0x21
            c == '%' -> MOD_SHIFT to 0x22
            c == '^' -> MOD_SHIFT to 0x23
            c == '&' -> MOD_SHIFT to 0x24
            c == '*' -> MOD_SHIFT to 0x25
            c == '(' -> MOD_SHIFT to 0x26
            c == ')' -> MOD_SHIFT to 0x27
            else -> null
        }
    }
}

package com.miditoqwertyMyx.android

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import java.io.ByteArrayInputStream
import java.io.DataInputStream
import java.io.File
import java.io.InputStream
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Simple SMF (Standard MIDI File) loader + sequencer.
 * Format 0/1. Note On / Note Off → absolute ms.
 */
object MidiFilePlayer {

    private const val TAG = "MidiFilePlayer"

    data class MidiSong(
        val id: String,
        val name: String,
        val path: String,
        val events: List<NoteEvent>,
        val durationMs: Long
    )

    data class NoteEvent(
        val timeMs: Long,
        val note: Int,
        val isOn: Boolean,
        val velocity: Int
    )

    private data class Raw(
        val tick: Long,
        val note: Int,
        val isOn: Boolean,
        val vel: Int
    )

    interface Listener {
        fun onNote(note: Int, isOn: Boolean)
        fun onProgress(positionMs: Long, durationMs: Long)
        fun onStateChanged(playing: Boolean, songName: String?)
        fun onSongEnded()
    }

    private val songs = CopyOnWriteArrayList<MidiSong>()
    private val handler = Handler(Looper.getMainLooper())
    private val playing = AtomicBoolean(false)
    private val paused = AtomicBoolean(false)

    @Volatile private var currentIndex = 0
    @Volatile private var positionMs = 0L
    @Volatile private var playStartElapsed = 0L
    @Volatile private var pauseAccumulated = 0L
    @Volatile private var nextEventIndex = 0
    @Volatile private var listener: Listener? = null

    private val activeNotes = HashSet<Int>()

    private val tickRunnable = object : Runnable {
        override fun run() {
            if (!playing.get() || paused.get()) return
            val song = currentSong() ?: return
            val now = positionMs()
            var i = nextEventIndex
            while (i < song.events.size && song.events[i].timeMs <= now) {
                fireEvent(song.events[i])
                i++
            }
            nextEventIndex = i
            positionMs = now
            listener?.onProgress(now, song.durationMs)

            if (i >= song.events.size) {
                onEnded()
                return
            }
            // next wake: either next event or 30ms tick
            val nextT = song.events[i].timeMs
            val delay = (nextT - now).coerceIn(1L, 30L)
            handler.postDelayed(this, delay)
        }
    }

    fun setListener(l: Listener?) {
        listener = l
    }

    fun getSongs(): List<MidiSong> = songs.toList()
    fun currentSong(): MidiSong? = songs.getOrNull(currentIndex)
    fun currentIndex(): Int = currentIndex
    fun isPlaying(): Boolean = playing.get() && !paused.get()
    fun isPaused(): Boolean = paused.get()
    fun positionMs(): Long = if (playing.get() && !paused.get()) {
        (SystemClock.elapsedRealtime() - playStartElapsed + pauseAccumulated).coerceAtLeast(0L)
    } else positionMs

    fun addSongFromFile(file: File): Boolean {
        return try {
            val events = parseSmf(ByteArrayInputStream(file.readBytes()))
            if (events.isEmpty()) {
                Log.w(TAG, "no note events in ${file.name}")
                return false
            }
            val dur = events.maxOf { it.timeMs } + 400
            songs.add(
                MidiSong(
                    id = "midi_${System.currentTimeMillis()}_${file.name}",
                    name = file.nameWithoutExtension,
                    path = file.absolutePath,
                    events = events,
                    durationMs = dur
                )
            )
            if (songs.size == 1) currentIndex = 0
            Log.i(TAG, "loaded ${file.name}: ${events.size} events, ${dur}ms")
            notifyState()
            true
        } catch (t: Throwable) {
            Log.e(TAG, "load failed ${file.name}", t)
            false
        }
    }

    fun addSongFromStream(name: String, input: InputStream): Boolean {
        return try {
            val events = parseSmf(ByteArrayInputStream(input.readBytes()))
            if (events.isEmpty()) return false
            val dur = events.maxOf { it.timeMs } + 400
            songs.add(
                MidiSong(
                    id = "midi_${System.currentTimeMillis()}_$name",
                    name = name.removeSuffix(".mid").removeSuffix(".MID").removeSuffix(".midi"),
                    path = "",
                    events = events,
                    durationMs = dur
                )
            )
            if (songs.size == 1) currentIndex = 0
            notifyState()
            true
        } catch (t: Throwable) {
            Log.e(TAG, "stream load failed", t)
            false
        }
    }

    fun removeCurrent() {
        if (songs.isEmpty()) return
        stop()
        songs.removeAt(currentIndex)
        if (currentIndex >= songs.size) currentIndex = (songs.size - 1).coerceAtLeast(0)
        notifyState()
    }

    fun clearSongs() {
        stop()
        songs.clear()
        currentIndex = 0
        notifyState()
    }

    fun select(index: Int) {
        if (index !in songs.indices) return
        stop()
        currentIndex = index
        positionMs = 0L
        nextEventIndex = 0
        notifyState()
    }

    fun next() {
        if (songs.isEmpty()) return
        select((currentIndex + 1) % songs.size)
        play()
    }

    fun prev() {
        if (songs.isEmpty()) return
        select(if (currentIndex <= 0) songs.size - 1 else currentIndex - 1)
        play()
    }

    fun play() {
        val song = currentSong() ?: return
        if (playing.get() && paused.get()) {
            paused.set(false)
            playStartElapsed = SystemClock.elapsedRealtime()
            handler.removeCallbacks(tickRunnable)
            handler.post(tickRunnable)
            notifyState()
            return
        }
        if (playing.get()) return

        playing.set(true)
        paused.set(false)
        if (nextEventIndex >= song.events.size) {
            nextEventIndex = 0
            positionMs = 0L
            pauseAccumulated = 0L
        }
        playStartElapsed = SystemClock.elapsedRealtime()
        pauseAccumulated = positionMs
        handler.removeCallbacks(tickRunnable)
        handler.post(tickRunnable)
        notifyState()
    }

    fun pause() {
        if (!playing.get() || paused.get()) return
        positionMs = positionMs()
        paused.set(true)
        handler.removeCallbacks(tickRunnable)
        releaseAllNotes()
        notifyState()
    }

    fun togglePlayPause() {
        when {
            !playing.get() -> play()
            paused.get() -> play()
            else -> pause()
        }
    }

    fun stop() {
        playing.set(false)
        paused.set(false)
        handler.removeCallbacks(tickRunnable)
        releaseAllNotes()
        positionMs = 0L
        pauseAccumulated = 0L
        nextEventIndex = 0
        notifyState()
    }

    /** Reset to start; keep playing if was playing. */
    fun reset() {
        val was = isPlaying()
        stop()
        if (was) play()
    }

    private fun fireEvent(ev: NoteEvent) {
        if (ev.isOn) activeNotes.add(ev.note) else activeNotes.remove(ev.note)
        try {
            listener?.onNote(ev.note, ev.isOn)
        } catch (t: Throwable) {
            Log.e(TAG, "onNote", t)
        }
    }

    private fun releaseAllNotes() {
        val held = activeNotes.toList()
        activeNotes.clear()
        for (n in held) {
            try {
                listener?.onNote(n, false)
            } catch (_: Throwable) {}
        }
    }

    private fun onEnded() {
        playing.set(false)
        paused.set(false)
        handler.removeCallbacks(tickRunnable)
        releaseAllNotes()
        positionMs = currentSong()?.durationMs ?: 0L
        nextEventIndex = currentSong()?.events?.size ?: 0
        notifyState()
        try {
            listener?.onSongEnded()
        } catch (_: Throwable) {}
    }

    private fun notifyState() {
        try {
            listener?.onStateChanged(isPlaying(), currentSong()?.name)
        } catch (_: Throwable) {}
    }

    // -------------------- SMF parser --------------------

    private fun parseSmf(input: InputStream): List<NoteEvent> {
        val dis = DataInputStream(input)
        val magic = ByteArray(4)
        dis.readFully(magic)
        if (String(magic) != "MThd") throw IllegalArgumentException("not a MIDI file")
        val headerLen = dis.readInt()
        val format = dis.readUnsignedShort()
        val nTracks = dis.readUnsignedShort()
        val division = dis.readUnsignedShort()
        if (headerLen > 6) dis.skipBytes(headerLen - 6)

        val ticksPerQuarter = if (division and 0x8000 != 0) 480 else division

        val rawNotes = ArrayList<Raw>()
        val tempos = ArrayList<Pair<Long, Long>>() // tick → µs/quarter
        tempos.add(0L to 500_000L)

        for (t in 0 until nTracks) {
            val trkMagic = ByteArray(4)
            dis.readFully(trkMagic)
            if (String(trkMagic) != "MTrk") throw IllegalArgumentException("bad track")
            val trkLen = dis.readInt()
            val trackData = ByteArray(trkLen)
            dis.readFully(trackData)
            parseTrack(trackData, rawNotes, tempos)
        }

        tempos.sortBy { it.first }

        fun tickToMs(tick: Long): Long {
            var ms = 0.0
            var prevTick = 0L
            var usPerQ = 500_000L
            var ti = 0
            while (ti < tempos.size && tempos[ti].first <= tick) {
                val (tt, us) = tempos[ti]
                ms += (tt - prevTick).toDouble() * usPerQ / ticksPerQuarter / 1000.0
                prevTick = tt
                usPerQ = us
                ti++
            }
            ms += (tick - prevTick).toDouble() * usPerQ / ticksPerQuarter / 1000.0
            return ms.toLong()
        }

        val events = rawNotes
            .map { NoteEvent(tickToMs(it.tick), it.note, it.isOn, it.vel) }
            .sortedWith(compareBy({ it.timeMs }, { if (it.isOn) 1 else 0 }))
            .toList()

        Log.d(TAG, "parsed format=$format tracks=$nTracks tpq=$ticksPerQuarter notes=${events.size}")
        return events
    }

    private fun parseTrack(
        data: ByteArray,
        out: ArrayList<Raw>,
        tempos: ArrayList<Pair<Long, Long>>
    ) {
        var pos = 0
        var tick = 0L
        var runningStatus = 0

        fun readVarLen(): Long {
            var v = 0L
            while (pos < data.size) {
                val b = data[pos].toInt() and 0xFF
                pos++
                v = (v shl 7) or (b and 0x7F).toLong()
                if (b and 0x80 == 0) break
            }
            return v
        }

        while (pos < data.size) {
            tick += readVarLen()
            if (pos >= data.size) break
            var status = data[pos].toInt() and 0xFF

            if (status and 0x80 == 0) {
                status = runningStatus
            } else {
                pos++
                if (status < 0xF0) runningStatus = status
            }

            when {
                status == 0xFF -> {
                    if (pos >= data.size) break
                    val type = data[pos].toInt() and 0xFF
                    pos++
                    val len = readVarLen().toInt()
                    if (type == 0x51 && len == 3 && pos + 3 <= data.size) {
                        val us = ((data[pos].toInt() and 0xFF) shl 16) or
                            ((data[pos + 1].toInt() and 0xFF) shl 8) or
                            (data[pos + 2].toInt() and 0xFF)
                        tempos.add(tick to us.toLong())
                    }
                    if (type == 0x2F) {
                        // end of track
                        pos += len
                        break
                    }
                    pos += len
                }
                status == 0xF0 || status == 0xF7 -> {
                    val len = readVarLen().toInt()
                    pos += len
                }
                status and 0xF0 == 0x90 -> {
                    if (pos + 2 > data.size) break
                    val note = data[pos].toInt() and 0xFF
                    val vel = data[pos + 1].toInt() and 0xFF
                    pos += 2
                    out.add(Raw(tick, note, vel > 0, vel))
                }
                status and 0xF0 == 0x80 -> {
                    if (pos + 2 > data.size) break
                    val note = data[pos].toInt() and 0xFF
                    val vel = data[pos + 1].toInt() and 0xFF
                    pos += 2
                    out.add(Raw(tick, note, false, vel))
                }
                status and 0xF0 == 0xA0 || status and 0xF0 == 0xB0 || status and 0xF0 == 0xE0 -> {
                    pos += 2
                }
                status and 0xF0 == 0xC0 || status and 0xF0 == 0xD0 -> {
                    pos += 1
                }
                else -> {
                    Log.w(TAG, "unknown status ${status.toString(16)} at $pos")
                    break
                }
            }
        }
    }
}

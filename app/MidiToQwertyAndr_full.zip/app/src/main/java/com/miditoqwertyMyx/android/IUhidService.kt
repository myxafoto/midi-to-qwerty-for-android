package com.miditoqwertyMyx.android

import android.os.Binder
import android.os.IBinder
import android.os.IInterface
import android.os.Parcel

/**
 * Manual Binder IPC (no AIDL compiler needed — server aidl binary is broken).
 */
interface IUhidService : IInterface {

    fun createDevices(): Boolean
    fun destroyDevices()
    fun tapKey(key: String): Boolean
    fun mouseMove(dx: Int, dy: Int): Boolean
    fun isActive(): Boolean
    fun status(): String

    abstract class Stub : Binder(), IUhidService {
        init {
            attachInterface(this, DESCRIPTOR)
        }

        override fun asBinder(): IBinder = this

        override fun onTransact(code: Int, data: Parcel, reply: Parcel?, flags: Int): Boolean {
            if (code == INTERFACE_TRANSACTION) {
                reply?.writeString(DESCRIPTOR)
                return true
            }
            data.enforceInterface(DESCRIPTOR)
            when (code) {
                TRANSACTION_createDevices -> {
                    val result = createDevices()
                    reply?.writeNoException()
                    reply?.writeInt(if (result) 1 else 0)
                    return true
                }
                TRANSACTION_destroyDevices -> {
                    destroyDevices()
                    reply?.writeNoException()
                    return true
                }
                TRANSACTION_tapKey -> {
                    val key = data.readString() ?: ""
                    val result = tapKey(key)
                    reply?.writeNoException()
                    reply?.writeInt(if (result) 1 else 0)
                    return true
                }
                TRANSACTION_mouseMove -> {
                    val dx = data.readInt()
                    val dy = data.readInt()
                    val result = mouseMove(dx, dy)
                    reply?.writeNoException()
                    reply?.writeInt(if (result) 1 else 0)
                    return true
                }
                TRANSACTION_isActive -> {
                    val result = isActive()
                    reply?.writeNoException()
                    reply?.writeInt(if (result) 1 else 0)
                    return true
                }
                TRANSACTION_status -> {
                    val result = status()
                    reply?.writeNoException()
                    reply?.writeString(result)
                    return true
                }
            }
            return super.onTransact(code, data, reply, flags)
        }

        companion object {
            const val DESCRIPTOR = "com.miditoqwertyMyx.android.IUhidService"
            private const val TRANSACTION_createDevices = FIRST_CALL_TRANSACTION
            private const val TRANSACTION_destroyDevices = FIRST_CALL_TRANSACTION + 1
            private const val TRANSACTION_tapKey = FIRST_CALL_TRANSACTION + 2
            private const val TRANSACTION_mouseMove = FIRST_CALL_TRANSACTION + 3
            private const val TRANSACTION_isActive = FIRST_CALL_TRANSACTION + 4
            private const val TRANSACTION_status = FIRST_CALL_TRANSACTION + 5

            fun asInterface(binder: IBinder?): IUhidService? {
                if (binder == null) return null
                val local = binder.queryLocalInterface(DESCRIPTOR)
                if (local != null && local is IUhidService) return local
                return Proxy(binder)
            }
        }

        private class Proxy(private val remote: IBinder) : IUhidService {
            override fun asBinder(): IBinder = remote

            override fun createDevices(): Boolean {
                val data = Parcel.obtain()
                val reply = Parcel.obtain()
                return try {
                    data.writeInterfaceToken(DESCRIPTOR)
                    remote.transact(TRANSACTION_createDevices, data, reply, 0)
                    reply.readException()
                    reply.readInt() != 0
                } finally {
                    reply.recycle()
                    data.recycle()
                }
            }

            override fun destroyDevices() {
                val data = Parcel.obtain()
                val reply = Parcel.obtain()
                try {
                    data.writeInterfaceToken(DESCRIPTOR)
                    remote.transact(TRANSACTION_destroyDevices, data, reply, 0)
                    reply.readException()
                } finally {
                    reply.recycle()
                    data.recycle()
                }
            }

            override fun tapKey(key: String): Boolean {
                val data = Parcel.obtain()
                val reply = Parcel.obtain()
                return try {
                    data.writeInterfaceToken(DESCRIPTOR)
                    data.writeString(key)
                    remote.transact(TRANSACTION_tapKey, data, reply, 0)
                    reply.readException()
                    reply.readInt() != 0
                } finally {
                    reply.recycle()
                    data.recycle()
                }
            }

            override fun mouseMove(dx: Int, dy: Int): Boolean {
                val data = Parcel.obtain()
                val reply = Parcel.obtain()
                return try {
                    data.writeInterfaceToken(DESCRIPTOR)
                    data.writeInt(dx)
                    data.writeInt(dy)
                    remote.transact(TRANSACTION_mouseMove, data, reply, 0)
                    reply.readException()
                    reply.readInt() != 0
                } finally {
                    reply.recycle()
                    data.recycle()
                }
            }

            override fun isActive(): Boolean {
                val data = Parcel.obtain()
                val reply = Parcel.obtain()
                return try {
                    data.writeInterfaceToken(DESCRIPTOR)
                    remote.transact(TRANSACTION_isActive, data, reply, 0)
                    reply.readException()
                    reply.readInt() != 0
                } finally {
                    reply.recycle()
                    data.recycle()
                }
            }

            override fun status(): String {
                val data = Parcel.obtain()
                val reply = Parcel.obtain()
                return try {
                    data.writeInterfaceToken(DESCRIPTOR)
                    remote.transact(TRANSACTION_status, data, reply, 0)
                    reply.readException()
                    reply.readString() ?: ""
                } finally {
                    reply.recycle()
                    data.recycle()
                }
            }
        }
    }
}

package com.miditoqwertyMyx.android

import android.app.Service
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Toast

/**
 * Semi-transparent gray overlay that draws all mapped click points
 * from the active preset. Tap anywhere or wait ~4s to dismiss.
 */
class PointsPreviewService : Service() {

    companion object {
        @Volatile private var running = false
        fun isRunning() = running
    }

    private var wm: WindowManager? = null
    private var overlay: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (running) {
            hideAndStop()
            return START_NOT_STICKY
        }
        PresetManager.init(this)
        showOverlay()
        running = true
        return START_NOT_STICKY
    }

    private fun showOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val points = PresetManager.getActivePreset()?.points?.values?.filter { it.enabled } ?: emptyList()

        val view = object : View(this) {
            private val bgPaint = Paint().apply { color = 0x88000000.toInt() }
            private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.CYAN
                style = Paint.Style.FILL
            }
            private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                style = Paint.Style.STROKE
                strokeWidth = 3f
            }
            private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = 28f
                textAlign = Paint.Align.CENTER
            }
            private val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = 0xFFCCCCCC.toInt()
                textSize = 36f
                textAlign = Paint.Align.CENTER
            }

            override fun onDraw(canvas: Canvas) {
                canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)
                canvas.drawText(
                    "Точки: ${points.size}  ·  тап — закрыть",
                    width / 2f, 80f, titlePaint
                )
                for (p in points) {
                    canvas.drawCircle(p.x, p.y, 18f, dotPaint)
                    canvas.drawCircle(p.x, p.y, 22f, ringPaint)
                    val label = MainActivity.noteNumberToName(p.note).substringBefore(" (")
                    canvas.drawText(label, p.x, p.y - 28f, textPaint)
                }
            }
        }.apply {
            setOnTouchListener { _, e ->
                if (e.action == MotionEvent.ACTION_DOWN) {
                    hideAndStop()
                    true
                } else false
            }
        }

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
            PixelFormat.TRANSLUCENT
        )

        try {
            wm?.addView(view, params)
            overlay = view
            if (points.isEmpty()) {
                Toast.makeText(this, "Нет точек в пресете", Toast.LENGTH_SHORT).show()
            }
            view.postDelayed({ hideAndStop() }, 8000)
        } catch (t: Throwable) {
            Toast.makeText(this, "Нужен overlay", Toast.LENGTH_SHORT).show()
            stopSelf()
        }
    }

    private fun hideAndStop() {
        try { overlay?.let { wm?.removeView(it) } } catch (_: Throwable) {}
        overlay = null
        running = false
        stopSelf()
    }

    override fun onDestroy() {
        hideAndStop()
        super.onDestroy()
    }
}

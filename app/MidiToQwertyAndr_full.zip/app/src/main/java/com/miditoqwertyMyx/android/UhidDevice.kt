package com.miditoqwertyMyx.android

import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Pure-Java UHID via UHID_CREATE2 (descriptor inline, no NDK).
 * Must run as shell/root (Shizuku UserService) to open /dev/uhid.
 */
class UhidDevice(private val name: String, private val reportDesc: ByteArray) {
    companion object {
        private const val TAG = "UhidDevice"
        private const val UHID_DESTROY = 1
        private const val UHID_CREATE2 = 11
        private const val UHID_INPUT2 = 12
        private const val HID_MAX_DESCRIPTOR_SIZE = 4096
        private const val UHID_DATA_MAX = 4096

        // Standard USB keyboard report descriptor (same idea as original native-lib)
        val KEYBOARD_DESC = byteArrayOf(
            0x05, 0x01, 0x09, 0x06, 0xA1.toByte(), 0x01,
            0x05, 0x07, 0x19, 0xE0.toByte(), 0x29, 0xE7.toByte(),
            0x15, 0x00, 0x25, 0x01, 0x75, 0x01, 0x95.toByte(), 0x08,
            0x81.toByte(), 0x02, 0x95.toByte(), 0x01, 0x75, 0x08, 0x81.toByte(), 0x03,
            0x95.toByte(), 0x05, 0x75, 0x01, 0x05, 0x08, 0x19, 0x01, 0x29, 0x05,
            0x91.toByte(), 0x02, 0x95.toByte(), 0x01, 0x75, 0x03, 0x91.toByte(), 0x03,
            0x95.toByte(), 0x06, 0x75, 0x08, 0x15, 0x00, 0x25, 0x65,
            0x05, 0x07, 0x19, 0x00, 0x29, 0x65, 0x81.toByte(), 0x00,
            0xC0.toByte()
        )

        // Relative mouse
        val MOUSE_DESC = byteArrayOf(
            0x05, 0x01, 0x09, 0x02, 0xA1.toByte(), 0x01,
            0x09, 0x01, 0xA1.toByte(), 0x00,
            0x05, 0x09, 0x19, 0x01, 0x29, 0x03,
            0x15, 0x00, 0x25, 0x01, 0x95.toByte(), 0x03, 0x75, 0x01, 0x81.toByte(), 0x02,
            0x95.toByte(), 0x01, 0x75, 0x05, 0x81.toByte(), 0x03,
            0x05, 0x01, 0x09, 0x30, 0x09, 0x31,
            0x15, 0x81.toByte(), 0x25, 0x7F,
            0x75, 0x08, 0x95.toByte(), 0x02, 0x81.toByte(), 0x06,
            0xC0.toByte(), 0xC0.toByte()
        )
    }

    private var raf: RandomAccessFile? = null
    val isOpen: Boolean get() = raf != null

    fun open(): Boolean {
        close()
        val path = "/dev/uhid"
        if (!File(path).exists()) {
            Log.e(TAG, "$path missing")
            return false
        }
        return try {
            val f = RandomAccessFile(path, "rw")
            val ok = writeCreate2(f)
            if (!ok) {
                f.close()
                return false
            }
            raf = f
            Log.i(TAG, "UHID created: $name")
            true
        } catch (e: Exception) {
            Log.e(TAG, "open failed for $name", e)
            false
        }
    }

    fun close() {
        try {
            raf?.let { f ->
                try {
                    val buf = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN)
                    buf.putInt(UHID_DESTROY)
                    f.write(buf.array())
                } catch (_: Exception) {}
                f.close()
            }
        } catch (_: Exception) {}
        raf = null
    }

    fun writeInput(report: ByteArray): Boolean {
        val f = raf ?: return false
        return try {
            // type(u32) + size(u16) + data[UHID_DATA_MAX]  -- pack minimal
            val buf = ByteBuffer.allocate(4 + 2 + UHID_DATA_MAX).order(ByteOrder.LITTLE_ENDIAN)
            buf.putInt(UHID_INPUT2)
            buf.putShort(report.size.toShort())
            buf.put(report)
            // pad rest
            while (buf.position() < 4 + 2 + UHID_DATA_MAX) buf.put(0)
            f.write(buf.array())
            true
        } catch (e: Exception) {
            Log.e(TAG, "writeInput failed", e)
            false
        }
    }

    private fun writeCreate2(f: RandomAccessFile): Boolean {
        // Layout of uhid_create2_req after type:
        // name[128], phys[64], uniq[64], rd_size u16, bus u16,
        // vendor u32, product u32, version u32, country u32, rd_data[4096]
        val rd = reportDesc
        if (rd.size > HID_MAX_DESCRIPTOR_SIZE) return false

        val createSize = 128 + 64 + 64 + 2 + 2 + 4 + 4 + 4 + 4 + HID_MAX_DESCRIPTOR_SIZE
        val buf = ByteBuffer.allocate(4 + createSize).order(ByteOrder.LITTLE_ENDIAN)
        buf.putInt(UHID_CREATE2)

        val nameBytes = ByteArray(128)
        val n = name.toByteArray(Charsets.UTF_8)
        System.arraycopy(n, 0, nameBytes, 0, minOf(n.size, 127))
        buf.put(nameBytes)

        buf.put(ByteArray(64)) // phys
        buf.put(ByteArray(64)) // uniq
        buf.putShort(rd.size.toShort())
        buf.putShort(0x03) // BUS_USB
        buf.putInt(0x1234) // vendor
        buf.putInt(0x5678) // product
        buf.putInt(0x0100) // version
        buf.putInt(0) // country
        buf.put(rd)
        val pad = HID_MAX_DESCRIPTOR_SIZE - rd.size
        if (pad > 0) buf.put(ByteArray(pad))

        f.write(buf.array())
        return true
    }
}

package com.miditoqwertyMyx.android

import android.os.SystemClock
import android.util.Log
import android.view.InputDevice
import android.view.InputEvent
import android.view.KeyEvent
import android.view.MotionEvent
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.SystemServiceHelper
import java.lang.reflect.Method

/**
 * Системный ввод через Shizuku → InputManager.injectInputEvent.
 * Клавиатура + попытка «режима ПК» через события мыши (SOURCE_MOUSE).
 * Полноценный uhid-девайс в системе без NDK недоступен на этой сборке.
 */
object KeyInjector {
    private const val TAG = "KeyInjector"

    // INJECT_INPUT_EVENT_MODE_ASYNC = 0
    private const val MODE_ASYNC = 0

    @Volatile
    private var ready = false

    private var injectMethod: Method? = null
    private var inputManager: Any? = null

    private val CHAR_TO_KEYCODE = mapOf(
        'a' to KeyEvent.KEYCODE_A, 'b' to KeyEvent.KEYCODE_B, 'c' to KeyEvent.KEYCODE_C,
        'd' to KeyEvent.KEYCODE_D, 'e' to KeyEvent.KEYCODE_E, 'f' to KeyEvent.KEYCODE_F,
        'g' to KeyEvent.KEYCODE_G, 'h' to KeyEvent.KEYCODE_H, 'i' to KeyEvent.KEYCODE_I,
        'j' to KeyEvent.KEYCODE_J, 'k' to KeyEvent.KEYCODE_K, 'l' to KeyEvent.KEYCODE_L,
        'm' to KeyEvent.KEYCODE_M, 'n' to KeyEvent.KEYCODE_N, 'o' to KeyEvent.KEYCODE_O,
        'p' to KeyEvent.KEYCODE_P, 'q' to KeyEvent.KEYCODE_Q, 'r' to KeyEvent.KEYCODE_R,
        's' to KeyEvent.KEYCODE_S, 't' to KeyEvent.KEYCODE_T, 'u' to KeyEvent.KEYCODE_U,
        'v' to KeyEvent.KEYCODE_V, 'w' to KeyEvent.KEYCODE_W, 'x' to KeyEvent.KEYCODE_X,
        'y' to KeyEvent.KEYCODE_Y, 'z' to KeyEvent.KEYCODE_Z,
        '0' to KeyEvent.KEYCODE_0, '1' to KeyEvent.KEYCODE_1, '2' to KeyEvent.KEYCODE_2,
        '3' to KeyEvent.KEYCODE_3, '4' to KeyEvent.KEYCODE_4, '5' to KeyEvent.KEYCODE_5,
        '6' to KeyEvent.KEYCODE_6, '7' to KeyEvent.KEYCODE_7, '8' to KeyEvent.KEYCODE_8,
        '9' to KeyEvent.KEYCODE_9
    )

    fun isReady(): Boolean = ready

    fun init(): Boolean {
        try {
            if (!Shizuku.pingBinder()) {
                ready = false
                return false
            }
            if (Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                ready = false
                return false
            }

            val binder = SystemServiceHelper.getSystemService("input")
            val wrapped = ShizukuBinderWrapper(binder)
            val stubClass = Class.forName("android.hardware.input.IInputManager\$Stub")
            val asInterface = stubClass.getMethod("asInterface", android.os.IBinder::class.java)
            inputManager = asInterface.invoke(null, wrapped)
            injectMethod = inputManager!!.javaClass.getMethod(
                "injectInputEvent",
                InputEvent::class.java,
                Int::class.javaPrimitiveType
            )
            ready = true
            Log.i(TAG, "KeyInjector ready")
            return true
        } catch (e: Exception) {
            ready = false
            Log.e(TAG, "init failed", e)
            return false
        }
    }

    /**
     * Попытка включить «как с компьютера»: несколько событий мыши.
     * На части прошивок появляется курсор; система видит SOURCE_MOUSE.
     */
    fun enablePcModeHint(): Boolean {
        if (!ready && !init()) return false
        return try {
            val now = SystemClock.uptimeMillis()
            // небольшое движение + hover-move
            injectMouse(now, 100f, 100f, MotionEvent.ACTION_HOVER_MOVE)
            injectMouse(now + 10, 110f, 105f, MotionEvent.ACTION_HOVER_MOVE)
            injectMouse(now + 20, 120f, 110f, MotionEvent.ACTION_MOVE)
            // «пустой» сдвиг, чтобы курсор не остался в углу
            injectMouse(now + 30, 200f, 200f, MotionEvent.ACTION_HOVER_MOVE)
            true
        } catch (e: Exception) {
            Log.e(TAG, "enablePcModeHint failed", e)
            false
        }
    }

    fun tapKey(key: String): Boolean {
        if (!ready && !init()) return false
        val resolved = resolveKey(key) ?: run {
            Log.w(TAG, "Unknown key: $key")
            return false
        }
        val meta = resolved.first
        val keyCode = resolved.second
        return try {
            val now = SystemClock.uptimeMillis()
            if (meta != 0) {
                injectKey(now, KeyEvent.ACTION_DOWN, metaKeyCode(meta), meta)
            }
            injectKey(now, KeyEvent.ACTION_DOWN, keyCode, meta)
            injectKey(now, KeyEvent.ACTION_UP, keyCode, meta)
            if (meta != 0) {
                injectKey(now, KeyEvent.ACTION_UP, metaKeyCode(meta), 0)
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "tapKey failed for $key", e)
            false
        }
    }

    private fun metaKeyCode(meta: Int): Int {
        return when {
            meta and KeyEvent.META_CTRL_ON != 0 -> KeyEvent.KEYCODE_CTRL_LEFT
            else -> KeyEvent.KEYCODE_SHIFT_LEFT
        }
    }

    private fun resolveKey(key: String): Pair<Int, Int>? {
        if (key.startsWith("ctrl_")) {
            val ch = key.removePrefix("ctrl_").lowercase().firstOrNull() ?: return null
            val kc = CHAR_TO_KEYCODE[ch] ?: return null
            return KeyEvent.META_CTRL_ON to kc
        }
        if (key.length != 1) return null
        val c = key[0]
        return when {
            c in 'A'..'Z' -> {
                val kc = CHAR_TO_KEYCODE[c.lowercaseChar()] ?: return null
                KeyEvent.META_SHIFT_ON to kc
            }
            c in 'a'..'z' || c in '0'..'9' -> {
                val kc = CHAR_TO_KEYCODE[c] ?: return null
                0 to kc
            }
            c == '!' -> KeyEvent.META_SHIFT_ON to KeyEvent.KEYCODE_1
            c == '@' -> KeyEvent.META_SHIFT_ON to KeyEvent.KEYCODE_2
            c == '#' -> KeyEvent.META_SHIFT_ON to KeyEvent.KEYCODE_3
            c == '$' -> KeyEvent.META_SHIFT_ON to KeyEvent.KEYCODE_4
            c == '%' -> KeyEvent.META_SHIFT_ON to KeyEvent.KEYCODE_5
            c == '^' -> KeyEvent.META_SHIFT_ON to KeyEvent.KEYCODE_6
            c == '&' -> KeyEvent.META_SHIFT_ON to KeyEvent.KEYCODE_7
            c == '*' -> KeyEvent.META_SHIFT_ON to KeyEvent.KEYCODE_8
            c == '(' -> KeyEvent.META_SHIFT_ON to KeyEvent.KEYCODE_9
            c == ')' -> KeyEvent.META_SHIFT_ON to KeyEvent.KEYCODE_0
            else -> null
        }
    }

    private fun injectKey(whenMs: Long, action: Int, keyCode: Int, meta: Int) {
        val ev = KeyEvent(
            whenMs, whenMs, action, keyCode, 0, meta,
            -1, 0,
            KeyEvent.FLAG_FROM_SYSTEM,
            InputDevice.SOURCE_KEYBOARD
        )
        injectMethod!!.invoke(inputManager, ev, MODE_ASYNC)
    }

    private fun injectMouse(whenMs: Long, x: Float, y: Float, action: Int) {
        val props = arrayOf(MotionEvent.PointerProperties().apply {
            id = 0
            toolType = MotionEvent.TOOL_TYPE_MOUSE
        })
        val coords = arrayOf(MotionEvent.PointerCoords().apply {
            this.x = x
            this.y = y
            pressure = 1f
            size = 1f
        })
        val ev = MotionEvent.obtain(
            whenMs, whenMs, action,
            1, props, coords,
            0, 0, 1f, 1f,
            -1, 0,
            InputDevice.SOURCE_MOUSE,
            0
        )
        try {
            injectMethod!!.invoke(inputManager, ev, MODE_ASYNC)
        } finally {
            ev.recycle()
        }
    }
}

package com.miditoqwertyMyx.android

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import org.json.JSONArray

/**
 * Presets + injection mode.
 * mode: "key"  = Shizuku/UHID key injection (original)
 *       "click"= Accessibility gesture taps
 */
object PresetManager {
    private const val TAG = "PresetManager"
    private const val PREFS = "click_presets"
    private const val KEY_PRESETS = "presets_json"
    private const val KEY_ACTIVE = "active_preset_id"
    private const val KEY_MODE = "injection_mode"

    private var prefs: SharedPreferences? = null
    private val presets = linkedMapOf<String, ClickPreset>()

    @Volatile var activePresetId: String? = null
        private set
    @Volatile var mode: String = "key"
        private set

    fun init(context: Context) {
        if (prefs != null) return
        prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        load()
    }

    fun getPresets(): List<ClickPreset> = presets.values.toList()
    fun getActivePreset(): ClickPreset? = activePresetId?.let { presets[it] }

    fun getPoint(note: Int): NotePoint? {
        if (mode != "click") return null
        return getActivePreset()?.points?.get(note)?.takeIf { it.enabled }
    }

    fun setMode(newMode: String) {
        mode = if (newMode == "click") "click" else "key"
        prefs?.edit()?.putString(KEY_MODE, mode)?.apply()
        Log.d(TAG, "mode=$mode")
    }

    fun setActivePreset(id: String?) {
        if (id != null && !presets.containsKey(id)) return
        activePresetId = id
        prefs?.edit()?.putString(KEY_ACTIVE, id)?.apply()
    }

    fun addPreset(preset: ClickPreset) {
        presets[preset.id] = preset
        save()
    }

    fun deletePreset(id: String) {
        presets.remove(id)
        if (activePresetId == id) {
            activePresetId = presets.keys.firstOrNull()
            prefs?.edit()?.putString(KEY_ACTIVE, activePresetId)?.apply()
        }
        save()
    }

    fun setPoint(note: Int, x: Float, y: Float) {
        val preset = getActivePreset() ?: return
        preset.points[note] = NotePoint(note, x, y, true)
        save()
        Log.d(TAG, "note $note → ($x,$y)")
    }

    fun removePoint(note: Int) {
        getActivePreset()?.points?.remove(note)
        save()
    }

    fun ensureDefault() {
        if (presets.isEmpty()) {
            val def = ClickPreset.createEmpty("Preset 1")
            addPreset(def)
            setActivePreset(def.id)
        }
    }

    private fun load() {
        val p = prefs ?: return
        mode = p.getString(KEY_MODE, "key") ?: "key"
        activePresetId = p.getString(KEY_ACTIVE, null)
        val json = p.getString(KEY_PRESETS, null) ?: return
        try {
            val arr = JSONArray(json)
            presets.clear()
            for (i in 0 until arr.length()) {
                val preset = ClickPreset.fromJson(arr.getJSONObject(i))
                presets[preset.id] = preset
            }
            if (activePresetId != null && !presets.containsKey(activePresetId)) {
                activePresetId = presets.keys.firstOrNull()
            }
        } catch (e: Exception) {
            Log.e(TAG, "load", e)
        }
    }

    private fun save() {
        val p = prefs ?: return
        try {
            val arr = JSONArray()
            presets.values.forEach { arr.put(it.toJson()) }
            p.edit()
                .putString(KEY_PRESETS, arr.toString())
                .putString(KEY_ACTIVE, activePresetId)
                .putString(KEY_MODE, mode)
                .apply()
        } catch (e: Exception) {
            Log.e(TAG, "save", e)
        }
    }
}

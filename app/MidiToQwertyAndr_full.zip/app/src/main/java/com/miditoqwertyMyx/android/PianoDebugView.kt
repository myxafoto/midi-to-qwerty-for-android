package com.miditoqwertyMyx.android

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import java.util.concurrent.ConcurrentHashMap

/**
 * Mini piano for debug: shows which MIDI notes are currently held.
 * Range: MIDI 36 (C2) … 96 (C7) — enough for most controllers.
 */
class PianoDebugView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyle: Int = 0
) : View(context, attrs, defStyle) {

    companion object {
        const val LOW = 36   // C2
        const val HIGH = 96  // C7
    }

    private val active = ConcurrentHashMap.newKeySet<Int>()

    private val whitePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0xFFF5F5F5.toInt()
    }
    private val whiteOnPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0xFF00E676.toInt()
    }
    private val blackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0xFF212121.toInt()
    }
    private val blackOnPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0xFFFF6E40.toInt()
    }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.5f
        color = 0xFF424242.toInt()
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFB0BEC5.toInt()
        textSize = 22f
        textAlign = Paint.Align.LEFT
    }

    private val tmp = RectF()

    fun noteOn(note: Int) {
        if (note in LOW..HIGH) {
            active.add(note)
            postInvalidate()
        }
    }

    fun noteOff(note: Int) {
        active.remove(note)
        postInvalidate()
    }

    fun clearAll() {
        active.clear()
        postInvalidate()
    }

    fun activeCount(): Int = active.size

    fun activeNotes(): Set<Int> = active.toSet()

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val h = ResolveSize(140, heightMeasureSpec)
        setMeasuredDimension(w, h)
    }

    private fun ResolveSize(desired: Int, measureSpec: Int): Int {
        val mode = MeasureSpec.getMode(measureSpec)
        val size = MeasureSpec.getSize(measureSpec)
        return when (mode) {
            MeasureSpec.EXACTLY -> size
            MeasureSpec.AT_MOST -> minOf(desired, size)
            else -> desired
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0 || h <= 0) return

        // Count white keys in range
        val whites = (LOW..HIGH).filter { MainActivity.isWhiteKey(it) }
        val nWhite = whites.size
        if (nWhite == 0) return

        val whiteW = w / nWhite
        val blackW = whiteW * 0.62f
        val blackH = h * 0.58f

        // Map note → white index
        val whiteIndex = HashMap<Int, Int>(nWhite)
        whites.forEachIndexed { i, n -> whiteIndex[n] = i }

        // Draw whites
        for ((i, note) in whites.withIndex()) {
            val left = i * whiteW
            tmp.set(left, 0f, left + whiteW, h)
            canvas.drawRect(tmp, if (active.contains(note)) whiteOnPaint else whitePaint)
            canvas.drawRect(tmp, strokePaint)
        }

        // Draw blacks on top
        for (note in LOW..HIGH) {
            if (!MainActivity.isBlackKey(note)) continue
            // black sits between previous white and next white
            val prevWhite = (note - 1).downTo(LOW).firstOrNull { MainActivity.isWhiteKey(it) } ?: continue
            val idx = whiteIndex[prevWhite] ?: continue
            val cx = (idx + 1) * whiteW
            val left = cx - blackW / 2f
            tmp.set(left, 0f, left + blackW, blackH)
            canvas.drawRect(tmp, if (active.contains(note)) blackOnPaint else blackPaint)
        }

        // Active count label
        val cnt = active.size
        if (cnt > 0) {
            canvas.drawText("×$cnt", 8f, h - 10f, labelPaint)
        }
    }
}

package com.miditoqwertyMyx.android

import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.media.midi.MidiDevice
import android.media.midi.MidiDeviceInfo
import android.media.midi.MidiManager
import android.media.midi.MidiOutputPort
import android.media.midi.MidiReceiver
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    companion object {
        private const val TAG = "MidiToQwertyTest"
        private const val REQUEST_CODE_OVERLAY = 1002
        private const val REQUEST_CODE_NOTIF = 1003
        private const val REQUEST_CODE_MIDI_FILE = 1004
        /** Numeric to compile on compileSdk < 33 */
        private const val API_TIRAMISU = 33
        private const val PERM_POST_NOTIFICATIONS = "android.permission.POST_NOTIFICATIONS"

        /** Set by SettingsActivity when pipette is waiting for a MIDI note. */
        @Volatile var pipetteWaiting = false

        private val NOTE_NAMES = arrayOf(
            "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"
        )

        private val PIANO_QWERTY_KEYS = arrayOf(
            "ctrl_1", "ctrl_2", "ctrl_3", "ctrl_4", "ctrl_5",
            "ctrl_6", "ctrl_7", "ctrl_8", "ctrl_9", "ctrl_0", "ctrl_q", "ctrl_w",
            "ctrl_e", "ctrl_r", "ctrl_t",
            "1", "!", "2", "@", "3", "4", "$", "5", "%",
            "6", "^", "7", "8", "*", "9", "(", "0", "q", "Q", "w", "W",
            "e", "E", "r", "t", "T", "y", "Y", "u", "i", "I", "o", "O",
            "p", "P", "a", "s", "S", "d", "D", "f", "g", "G", "h", "H",
            "j", "J", "k", "l", "L", "z", "Z", "x", "c", "C", "v", "V",
            "b", "B", "n", "m",
            "ctrl_y", "ctrl_u", "ctrl_i", "ctrl_o",
            "ctrl_p", "ctrl_a", "ctrl_s", "ctrl_d", "ctrl_f", "ctrl_g", "ctrl_h",
            "ctrl_j"
        )

        fun noteNumberToName(noteNumber: Int): String {
            if (noteNumber < 0 || noteNumber > 127) return "INVALID"
            val octave = (noteNumber / 12) - 1
            val noteIndex = noteNumber % 12
            return "${NOTE_NAMES[noteIndex]}$octave (MIDI $noteNumber)"
        }

        fun noteToQwertyKey(noteNumber: Int): String {
            val idx = noteNumber - 21
            if (idx < 0 || idx >= PIANO_QWERTY_KEYS.size) return "?"
            return PIANO_QWERTY_KEYS[idx]
        }

        fun keyToInsertChar(key: String): String {
            if (key.startsWith("ctrl_")) {
                val rest = key.removePrefix("ctrl_")
                return if (rest.length == 1) rest.lowercase() else rest
            }
            return when (key) {
                "!", "@", "$", "%", "^", "*", "(", ")" -> key
                else -> if (key.length == 1) key else key
            }
        }

        /** White-key MIDI numbers: C,D,E,F,G,A,B (no sharps). */
        fun isWhiteKey(note: Int): Boolean {
            val n = note % 12
            return n == 0 || n == 2 || n == 4 || n == 5 || n == 7 || n == 9 || n == 11
        }

        /** Black-key MIDI numbers: C#,D#,F#,G#,A#. */
        fun isBlackKey(note: Int): Boolean = !isWhiteKey(note)

        fun whiteKeysBetween(low: Int, high: Int): List<Int> {
            val a = minOf(low, high)
            val b = maxOf(low, high)
            return (a..b).filter { isWhiteKey(it) }
        }

        fun blackKeysBetween(low: Int, high: Int): List<Int> {
            val a = minOf(low, high)
            val b = maxOf(low, high)
            return (a..b).filter { isBlackKey(it) }
        }
    }

    private lateinit var overlayStatus: TextView
    private lateinit var notifStatus: TextView
    private lateinit var a11yStatus: TextView
    private lateinit var noteText: TextView
    private lateinit var midiStatus: TextView
    private lateinit var sampleText: TextView
    private lateinit var testInput: EditText
    private lateinit var btnOverlay: Button
    private lateinit var btnNotif: Button
    private lateinit var btnA11y: Button
    private lateinit var btnFloat: Button
    private lateinit var pianoDebug: PianoDebugView
    private lateinit var activeNotesText: TextView
    private lateinit var midiPlaylistText: TextView

    private var midiManager: MidiManager? = null
    private var midiOutputPort: MidiOutputPort? = null
    private var currentDevice: MidiDevice? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    /** Running status for MIDI stream parsing. */
    @Volatile private var midiRunningStatus: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        overlayStatus = findViewById(R.id.overlayStatus)
        notifStatus = findViewById(R.id.notifStatus)
        a11yStatus = findViewById(R.id.a11yStatus)
        noteText = findViewById(R.id.noteText)
        midiStatus = findViewById(R.id.midiStatus)
        sampleText = findViewById(R.id.sample_text)
        testInput = findViewById(R.id.testInput)
        btnOverlay = findViewById(R.id.btnOverlay)
        btnNotif = findViewById(R.id.btnNotif)
        btnA11y = findViewById(R.id.btnA11y)
        btnFloat = findViewById(R.id.btnFloat)
        pianoDebug = findViewById(R.id.pianoDebug)
        activeNotesText = findViewById(R.id.activeNotesText)
        midiPlaylistText = findViewById(R.id.midiPlaylistText)

        PresetManager.init(this)
        PresetManager.ensureDefault()

        sampleText.text = "CLICK: Accessibility · KEY: Shizuku/UHID (в настройках)"

        btnOverlay.setOnClickListener { requestOverlayPermission() }
        btnNotif.setOnClickListener { requestNotificationPermission() }
        btnA11y.setOnClickListener { openAccessibilitySettings() }
        btnFloat.setOnClickListener { toggleFloatingWindow() }
        findViewById<Button>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        findViewById<Button>(R.id.btnLoadMidi).setOnClickListener { openMidiFilePicker() }

        updateOverlayStatus()
        updateNotifStatus()
        updateA11yStatus()
        updateFloatButtonText()
        refreshPlaylistLabel()

        setupMidi()
        setupMidiFilePlayer()
    }

    override fun onResume() {
        super.onResume()
        updateOverlayStatus()
        updateNotifStatus()
        updateA11yStatus()
        updateFloatButtonText()
    }

    override fun onDestroy() {
        super.onDestroy()
        cleanupMidi()
        MidiFilePlayer.setListener(null)
        // don't stop playback on rotate/destroy if service holds UI — stop for safety
        try { MidiFilePlayer.stop() } catch (_: Exception) {}
        try { UhidClient.stop() } catch (_: Exception) {}
    }

    // ==================== MIDI FILE ====================

    private fun openMidiFilePicker() {
        // type=*/* without EXTRA_MIME_TYPES — many file managers hide .mid
        // when filtered by audio/midi (they only show .rtx / octet-stream).
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        try {
            startActivityForResult(intent, REQUEST_CODE_MIDI_FILE)
        } catch (t: Throwable) {
            // fallback
            try {
                val fallback = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                }
                startActivityForResult(fallback, REQUEST_CODE_MIDI_FILE)
            } catch (t2: Throwable) {
                Toast.makeText(this, "Не удалось открыть файловый менеджер", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun setupMidiFilePlayer() {
        MidiFilePlayer.setListener(object : MidiFilePlayer.Listener {
            override fun onNote(note: Int, isOn: Boolean) {
                // Feed into the same pipeline as hardware MIDI
                onNoteEvent(note, isOn)
            }

            override fun onProgress(positionMs: Long, durationMs: Long) {
                // optional: could update a progress label
            }

            override fun onStateChanged(playing: Boolean, songName: String?) {
                mainHandler.post { refreshPlaylistLabel() }
            }

            override fun onSongEnded() {
                mainHandler.post {
                    Toast.makeText(this@MainActivity, "MIDI закончился", Toast.LENGTH_SHORT).show()
                    refreshPlaylistLabel()
                }
            }
        })
    }

    private fun refreshPlaylistLabel() {
        val songs = MidiFilePlayer.getSongs()
        if (songs.isEmpty()) {
            midiPlaylistText.text = "Плейлист: пусто — нажми «Загрузить MIDI»"
            return
        }
        val idx = MidiFilePlayer.currentIndex()
        val sb = StringBuilder()
        sb.append("Плейлист (${songs.size}):\n")
        songs.forEachIndexed { i, s ->
            val mark = when {
                i == idx && MidiFilePlayer.isPlaying() -> "▶ "
                i == idx && MidiFilePlayer.isPaused() -> "▮ "
                i == idx -> "● "
                else -> "  "
            }
            sb.append("$mark${i + 1}. ${s.name} (${s.events.size} ev)\n")
        }
        midiPlaylistText.text = sb.toString().trimEnd()
    }

    private fun importMidiUri(uri: android.net.Uri) {
        try {
            var name = "song.mid"
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                val idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && c.moveToFirst()) {
                    name = c.getString(idx) ?: name
                }
            }
            if (name == "song.mid") {
                name = uri.lastPathSegment?.substringAfterLast('/') ?: name
            }
            contentResolver.openInputStream(uri)?.use { stream ->
                val ok = MidiFilePlayer.addSongFromStream(name, stream)
                if (ok) {
                    Toast.makeText(this, "Загружено: $name", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(
                        this,
                        "Не MIDI (нужен SMF .mid/.midi/.rtx): $name",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            } ?: Toast.makeText(this, "Не открыть файл", Toast.LENGTH_SHORT).show()
        } catch (t: Throwable) {
            Log.e(TAG, "importMidiUri", t)
            Toast.makeText(this, "Ошибка: ${t.message}", Toast.LENGTH_SHORT).show()
        }
        refreshPlaylistLabel()
    }

    // ==================== OVERLAY ====================

    private fun updateOverlayStatus() {
        val granted = Settings.canDrawOverlays(this)
        if (granted) {
            overlayStatus.text = "Overlay: РАЗРЕШЕНО ✓"
            overlayStatus.setTextColor(0xFF4CAF50.toInt())
        } else {
            overlayStatus.text = "Overlay: НЕТ разрешения"
            overlayStatus.setTextColor(0xFFF44336.toInt())
        }
    }

    private fun requestOverlayPermission() {
        if (Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Разрешение уже есть", Toast.LENGTH_SHORT).show()
            updateOverlayStatus()
            return
        }
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        startActivityForResult(intent, REQUEST_CODE_OVERLAY)
        Toast.makeText(this, "Включите «Отображать поверх других приложений»", Toast.LENGTH_LONG).show()
    }

    // ==================== NOTIFICATIONS ====================
    // API 33 constants avoided so compileSdk < 33 still builds.

    private fun updateNotifStatus() {
        if (Build.VERSION.SDK_INT < API_TIRAMISU) {
            notifStatus.text = "Уведомления: не требуются (API < 33)"
            notifStatus.setTextColor(0xFF4CAF50.toInt())
            return
        }
        val granted = ContextCompat.checkSelfPermission(
            this, PERM_POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
        if (granted) {
            notifStatus.text = "Уведомления: РАЗРЕШЕНО ✓"
            notifStatus.setTextColor(0xFF4CAF50.toInt())
        } else {
            notifStatus.text = "Уведомления: НЕТ (для foreground-сервиса)"
            notifStatus.setTextColor(0xFFFF9800.toInt())
        }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT < API_TIRAMISU) {
            Toast.makeText(this, "На этой версии Android не нужно", Toast.LENGTH_SHORT).show()
            return
        }
        if (ContextCompat.checkSelfPermission(this, PERM_POST_NOTIFICATIONS)
            == PackageManager.PERMISSION_GRANTED
        ) {
            Toast.makeText(this, "Уже выдано", Toast.LENGTH_SHORT).show()
            updateNotifStatus()
            return
        }
        ActivityCompat.requestPermissions(
            this, arrayOf(PERM_POST_NOTIFICATIONS), REQUEST_CODE_NOTIF
        )
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_NOTIF) {
            updateNotifStatus()
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Уведомления разрешены", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ==================== ACCESSIBILITY ====================

    private fun isAccessibilityEnabled(): Boolean {
        return try {
            val svc = ComponentName(this, ClickAccessibilityService::class.java).flattenToString()
            val enabled = Settings.Secure.getString(
                contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: ""
            enabled.contains(svc)
        } catch (_: Throwable) {
            false
        }
    }

    private fun updateA11yStatus() {
        val on = isAccessibilityEnabled() || ClickAccessibilityService.isRunning()
        if (on) {
            a11yStatus.text = "Accessibility: ВКЛ ✓"
            a11yStatus.setTextColor(0xFF4CAF50.toInt())
        } else {
            a11yStatus.text = "Accessibility: ВЫКЛ (нужен для CLICK)"
            a11yStatus.setTextColor(0xFFF44336.toInt())
        }
    }

    private fun openAccessibilitySettings() {
        try {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(
                this,
                "Найди «${getString(R.string.app_name)}» и включи",
                Toast.LENGTH_LONG
            ).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Не удалось открыть настройки", Toast.LENGTH_SHORT).show()
        }
    }

    // ==================== FLOATING WINDOW ====================

    private fun updateFloatButtonText() {
        btnFloat.text = if (FloatingWindowService.isRunning) {
            "Скрыть плавающее окно"
        } else {
            "Показать плавающее окно"
        }
    }

    private fun toggleFloatingWindow() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Сначала дай разрешение Overlay", Toast.LENGTH_SHORT).show()
            requestOverlayPermission()
            return
        }
        if (FloatingWindowService.isRunning) {
            stopService(Intent(this, FloatingWindowService::class.java))
            Toast.makeText(this, "Плавающее окно скрыто", Toast.LENGTH_SHORT).show()
        } else {
            val i = Intent(this, FloatingWindowService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(i)
            } else {
                startService(i)
            }
            Toast.makeText(this, "Окно можно таскать; ✕ — закрыть", Toast.LENGTH_SHORT).show()
        }
        mainHandler.postDelayed({ updateFloatButtonText() }, 200)
    }

    private fun notifyFloatNote(noteNumber: Int, isDown: Boolean) {
        if (!FloatingWindowService.isRunning) return
        try {
            startService(
                Intent(this, FloatingWindowService::class.java).apply {
                    action = FloatingWindowService.ACTION_NOTE
                    putExtra(FloatingWindowService.EXTRA_NOTE_NUM, noteNumber)
                    putExtra(FloatingWindowService.EXTRA_IS_DOWN, isDown)
                }
            )
        } catch (_: Throwable) {}
    }

    // ==================== MIDI ====================

    private fun setupMidi() {
        midiManager = getSystemService(MIDI_SERVICE) as? MidiManager
        if (midiManager == null) {
            midiStatus.text = "MIDI: MidiManager недоступен"
            return
        }
        val devices = midiManager!!.devices
        midiStatus.text = "MIDI: найдено устройств = ${devices.size}"
        devices.forEach { openMidiDevice(it) }

        midiManager!!.registerDeviceCallback(object : MidiManager.DeviceCallback() {
            override fun onDeviceAdded(device: MidiDeviceInfo) {
                mainHandler.post {
                    midiStatus.text = "MIDI: устройство добавлено"
                    openMidiDevice(device)
                }
            }
            override fun onDeviceRemoved(device: MidiDeviceInfo) {
                mainHandler.post { midiStatus.text = "MIDI: устройство отключено" }
            }
        }, mainHandler)
    }

    private fun openMidiDevice(info: MidiDeviceInfo) {
        if (info.outputPortCount <= 0) return

        midiManager?.openDevice(info, { device ->
            if (device == null) {
                mainHandler.post { midiStatus.text = "MIDI: не удалось открыть" }
                return@openDevice
            }
            currentDevice = device
            midiOutputPort?.close()
            midiRunningStatus = 0
            midiOutputPort = device.openOutputPort(0)
            midiOutputPort?.connect(object : MidiReceiver() {
                override fun onSend(msg: ByteArray, offset: Int, count: Int, timestamp: Long) {
                    // Parse ENTIRE buffer — devices pack multiple notes in one packet
                    parseMidiBuffer(msg, offset, count)
                }
            })
            mainHandler.post {
                val name = info.properties.getString(MidiDeviceInfo.PROPERTY_NAME) ?: "unknown"
                midiStatus.text = "MIDI: $name (слушаем, multi-msg)"
            }
        }, mainHandler)
    }

    /**
     * Walk the whole MIDI byte stream.
     * Supports:
     *  - multiple messages per onSend
     *  - running status (no status byte on subsequent notes)
     *  - Note On (0x9n), Note Off (0x8n), Note On vel=0 = off
     *  - skips SysEx / real-time / other channel messages safely
     */
    private fun parseMidiBuffer(msg: ByteArray, offset: Int, count: Int) {
        var i = offset
        val end = offset + count
        while (i < end) {
            var b = msg[i].toInt() and 0xFF

            // Real-time messages (single byte) — skip
            if (b >= 0xF8) {
                i++
                continue
            }

            // System common / SysEx start
            if (b >= 0xF0) {
                midiRunningStatus = 0
                when (b) {
                    0xF0 -> { // SysEx — skip until 0xF7 or end
                        i++
                        while (i < end && (msg[i].toInt() and 0xFF) != 0xF7) i++
                        if (i < end) i++ // consume F7
                    }
                    0xF1, 0xF3 -> i += 2  // 1 data byte
                    0xF2 -> i += 3       // 2 data bytes
                    else -> i++          // F4–F6, F7 alone
                }
                continue
            }

            val status: Int
            if (b and 0x80 != 0) {
                // New status byte
                status = b
                midiRunningStatus = status
                i++
            } else {
                // Running status — reuse previous
                status = midiRunningStatus
                if (status == 0) {
                    i++ // orphan data, skip
                    continue
                }
            }

            val cmd = status and 0xF0
            val dataBytes = when (cmd) {
                0x80, 0x90, 0xA0, 0xB0, 0xE0 -> 2
                0xC0, 0xD0 -> 1
                else -> 0
            }

            if (i + dataBytes > end) break // incomplete — wait next packet

            val d1 = if (dataBytes >= 1) msg[i].toInt() and 0xFF else 0
            val d2 = if (dataBytes >= 2) msg[i + 1].toInt() and 0xFF else 0
            i += dataBytes

            when (cmd) {
                0x90 -> onNoteEvent(d1, d2 > 0) // note on (vel 0 = off)
                0x80 -> onNoteEvent(d1, false)  // note off
            }
        }
    }

    private fun onNoteEvent(noteNumber: Int, isDown: Boolean) {
        // Always update debug piano + active list
        mainHandler.post {
            if (isDown) pianoDebug.noteOn(noteNumber) else pianoDebug.noteOff(noteNumber)
            refreshActiveNotesLabel()
        }

        notifyFloatNote(noteNumber, isDown)

        if (!isDown) return

        val noteLabel = noteNumberToName(noteNumber)
        val key = noteToQwertyKey(noteNumber)
        val insertChar = keyToInsertChar(key)

        Log.d(TAG, "Note $noteNumber → key=$key mode=${PresetManager.mode}")

        val calibPrefs = getSharedPreferences("float_calib", MODE_PRIVATE)
        if (FloatingWindowService.isCalibrating
            || FloatingWindowService.isWhiteFillActive
            || calibPrefs.getBoolean("edit_one", false)
            || CoordinatePickerService.isRunning()
        ) {
            mainHandler.post { noteText.text = "$noteLabel\nкалибровка…" }
            return
        }

        // Pipette from Settings
        if (pipetteWaiting) {
            pipetteWaiting = false
            mainHandler.post {
                try {
                    startService(
                        Intent(this, CoordinatePickerService::class.java)
                            .putExtra(CoordinatePickerService.EXTRA_NOTE, noteNumber)
                    )
                } catch (_: Throwable) {}
                noteText.text = "$noteLabel\nпипетка → тап"
            }
            return
        }

        if (PresetManager.mode == "click") {
            val point = PresetManager.getPoint(noteNumber)
            val ok = if (point != null) {
                ClickAccessibilityService.performClick(point.x, point.y)
            } else false
            mainHandler.post {
                val status = when {
                    point == null -> "нет точки в пресете"
                    ok -> "CLICK OK (${point.x.toInt()},${point.y.toInt()})"
                    else -> "CLICK fail (Accessibility?)"
                }
                noteText.text = "$noteLabel\n→ tap\n$status"
            }
            return
        }

        // KEY mode
        val viaUhid = UhidClient.tapKey(key)
        val viaInject = if (!viaUhid) KeyInjector.tapKey(key) else false

        mainHandler.post {
            val status = when {
                viaUhid -> "UHID OK"
                viaInject -> "inject OK"
                else -> "fail (Shizuku/uhid? → настройки)"
            }
            noteText.text = "$noteLabel\n→ $key\n$status"
            if (insertChar.isNotEmpty() && insertChar != "?") {
                simulateTextInput(testInput, insertChar)
            }
        }
    }

    private fun refreshActiveNotesLabel() {
        val notes = pianoDebug.activeNotes().sorted()
        if (notes.isEmpty()) {
            activeNotesText.text = "Активно: —"
            return
        }
        val names = notes.joinToString(" ") { n ->
            val short = noteNumberToName(n).substringBefore(" (")
            short
        }
        activeNotesText.text = "Активно (${notes.size}): $names"
    }

    private fun simulateTextInput(editText: EditText, textToInsert: String) {
        try {
            var start = editText.selectionStart
            var end = editText.selectionEnd
            if (start < 0 || end < 0) {
                start = editText.text.length
                end = start
            }
            editText.text.replace(minOf(start, end), maxOf(start, end), textToInsert)
            val pos = minOf(start, end) + textToInsert.length
            editText.setSelection(pos.coerceAtMost(editText.text.length))
        } catch (e: Exception) {
            Log.e(TAG, "simulateTextInput failed", e)
        }
    }

    private fun cleanupMidi() {
        try {
            midiOutputPort?.close()
            currentDevice?.close()
        } catch (_: Exception) {}
        midiOutputPort = null
        currentDevice = null
        midiRunningStatus = 0
        try {
            pianoDebug.clearAll()
            activeNotesText.text = "Активно: —"
        } catch (_: Exception) {}
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE_OVERLAY) {
            updateOverlayStatus()
            if (Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Overlay разрешение получено", Toast.LENGTH_SHORT).show()
            }
            return
        }
        if (requestCode == REQUEST_CODE_MIDI_FILE && resultCode == RESULT_OK && data != null) {
            val clip = data.clipData
            if (clip != null) {
                for (i in 0 until clip.itemCount) {
                    clip.getItemAt(i).uri?.let { importMidiUri(it) }
                }
            } else {
                data.data?.let { importMidiUri(it) }
            }
        }
    }
}

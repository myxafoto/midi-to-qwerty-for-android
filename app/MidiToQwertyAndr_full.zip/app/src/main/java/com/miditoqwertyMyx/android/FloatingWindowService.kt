package com.miditoqwertyMyx.android

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast

/**
 * Compact floating control:
 *  ▶ Start  — sequential calibration (MIDI note → tap → next)
 *  👁 Show points overlay
 *  ⬜ White-keys fill: leftmost + tap, rightmost + tap → interpolate
 *  ⬛ Black-keys fill: 6 pattern points + right boundary → tile pattern
 *  ⚙ Settings — presets, delay ms, edit one, KEY/CLICK
 */
class FloatingWindowService : Service() {

    companion object {
        const val ACTION_UPDATE = "com.miditoqwertyMyx.android.FLOAT_UPDATE"
        const val ACTION_CLOSE = "com.miditoqwertyMyx.android.FLOAT_CLOSE"
        const val ACTION_NOTE = "com.miditoqwertyMyx.android.FLOAT_NOTE"
        const val EXTRA_NOTE = "note"
        const val EXTRA_KEY = "key"
        const val EXTRA_NOTE_NUM = "note_num"
        const val EXTRA_IS_DOWN = "is_down"

        private const val CHANNEL_ID = "midi_float_channel"
        private const val NOTIF_ID = 42
        private const val TAG = "FloatPanel"
        private const val PREFS = "float_calib"

        /** How many black pattern points to capture before right boundary. */
        private const val BLACK_PATTERN_COUNT = 6

        @Volatile
        var isRunning = false
            private set

        @Volatile
        var isCalibrating = false
            private set

        /** Any fill wizard active (blocks play inject). */
        @Volatile
        var isWhiteFillActive = false
            private set
    }

    private var windowManager: WindowManager? = null
    private var floatView: View? = null
    private var params: WindowManager.LayoutParams? = null

    private var floatStatus: TextView? = null
    private var btnStart: TextView? = null
    private var btnSettings: TextView? = null
    private var btnShowPoints: TextView? = null
    private var btnWhiteFill: TextView? = null
    private var btnBlackFill: TextView? = null
    private var settingsPanel: View? = null
    private var tvPresetName: TextView? = null
    private var tvDelayMs: TextView? = null
    private var btnMidiPlay: TextView? = null
    private var tvMidiSong: TextView? = null

    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f
    private var settingsOpen = false
    private var editOneWaiting = false
    private var receiverRegistered = false

    // White-fill state machine
    // 0 = idle, 1 = wait left MIDI, 2 = wait left tap, 3 = wait right MIDI, 4 = wait right tap
    private var whiteStep = 0
    private var whiteLeftNote = -1
    private var whiteLeftX = 0f
    private var whiteLeftY = 0f
    private var whiteRightNote = -1

    // Black-fill state machine
    // 0 = idle
    // 1..BLACK_PATTERN_COUNT = wait MIDI for pattern point N, then tap
    // after pattern: wait right MIDI
    // mode flag: blackWaitTap = true means we have MIDI and wait screen tap
    private var blackStep = 0          // 0 idle, 1..6 collecting pattern, 7 wait right MIDI
    private var blackWaitTap = false
    private var blackPendingNote = -1
    private val blackPattern = ArrayList<Pair<Int, Pair<Float, Float>>>(BLACK_PATTERN_COUNT)
    private var blackRightNote = -1

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                ACTION_NOTE -> {
                    val note = intent.getIntExtra(EXTRA_NOTE_NUM, -1)
                    val down = intent.getBooleanExtra(EXTRA_IS_DOWN, false)
                    if (down && note in 21..107) onMidiNote(note)
                }
                "com.miditoqwertyMyx.android.PRESET_UPDATED" -> {
                    refreshPresetLabel()
                    if (isCalibrating) {
                        floatStatus?.text = "● жди ноту…"
                        floatStatus?.setTextColor(0xFFFFD54F.toInt())
                    } else if (!editOneWaiting && whiteStep == 0 && blackStep == 0) {
                        refreshStatusIdle()
                    }
                }
                "com.miditoqwertyMyx.android.WHITE_TAP" -> {
                    val x = intent.getFloatExtra("x", 0f)
                    val y = intent.getFloatExtra("y", 0f)
                    onFillTap(x, y)
                }
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        PresetManager.init(this)
        PresetManager.ensureDefault()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        startAsForeground()
        showFloatingWindow()
        registerReceivers()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CLOSE -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_NOTE -> {
                val note = intent.getIntExtra(EXTRA_NOTE_NUM, -1)
                val down = intent.getBooleanExtra(EXTRA_IS_DOWN, false)
                if (down && note in 21..107) onMidiNote(note)
            }
        }
        return START_STICKY
    }

    private fun registerReceivers() {
        val f = IntentFilter().apply {
            addAction(ACTION_NOTE)
            addAction("com.miditoqwertyMyx.android.PRESET_UPDATED")
            addAction("com.miditoqwertyMyx.android.WHITE_TAP")
        }
        try {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(receiver, f)
            receiverRegistered = true
        } catch (t: Throwable) {
            Log.e(TAG, "registerReceiver", t)
        }
    }

    private fun startAsForeground() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "MIDI floating", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notif = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("MIDI control")
                .setContentText("Плавающая панель")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentIntent(openApp)
                .setOngoing(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("MIDI control")
                .setContentText("Плавающая панель")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentIntent(openApp)
                .setOngoing(true)
                .build()
        }
        startForeground(NOTIF_ID, notif)
    }

    private fun showFloatingWindow() {
        floatView = LayoutInflater.from(this).inflate(R.layout.float_window, null)
        floatStatus = floatView!!.findViewById(R.id.floatStatus)
        btnStart = floatView!!.findViewById(R.id.btnStart)
        btnSettings = floatView!!.findViewById(R.id.btnSettings)
        btnShowPoints = floatView!!.findViewById(R.id.btnShowPoints)
        btnWhiteFill = floatView!!.findViewById(R.id.btnWhiteFill)
        btnBlackFill = floatView!!.findViewById(R.id.btnBlackFill)
        settingsPanel = floatView!!.findViewById(R.id.settingsPanel)
        tvPresetName = floatView!!.findViewById(R.id.tvPresetName)
        tvDelayMs = floatView!!.findViewById(R.id.tvDelayMs)
        btnMidiPlay = floatView!!.findViewById(R.id.btnMidiPlay)
        tvMidiSong = floatView!!.findViewById(R.id.tvMidiSong)

        floatView!!.findViewById<TextView>(R.id.floatClose).setOnClickListener {
            stopCalibration()
            cancelWhiteFill()
            cancelBlackFill()
            stopSelf()
        }

        btnStart?.setOnClickListener { toggleCalibration() }
        btnSettings?.setOnClickListener { toggleSettings() }
        btnShowPoints?.setOnClickListener { showPointsPreview() }
        btnWhiteFill?.setOnClickListener { toggleWhiteFill() }
        btnBlackFill?.setOnClickListener { toggleBlackFill() }

        floatView!!.findViewById<TextView>(R.id.btnPresetPrev).setOnClickListener { cyclePreset(-1) }
        floatView!!.findViewById<TextView>(R.id.btnPresetNext).setOnClickListener { cyclePreset(+1) }
        floatView!!.findViewById<TextView>(R.id.btnPresetAdd).setOnClickListener { addPreset() }
        floatView!!.findViewById<TextView>(R.id.btnPresetDel).setOnClickListener { delPreset() }
        floatView!!.findViewById<TextView>(R.id.btnEditOne).setOnClickListener { startEditOne() }
        floatView!!.findViewById<TextView>(R.id.btnToggleMode).setOnClickListener { toggleMode() }

        floatView!!.findViewById<TextView>(R.id.btnDelayMinus).setOnClickListener { changeDelay(-1) }
        floatView!!.findViewById<TextView>(R.id.btnDelayPlus).setOnClickListener { changeDelay(+1) }

        // MIDI file transport
        floatView!!.findViewById<TextView>(R.id.btnMidiPrev).setOnClickListener {
            if (MidiFilePlayer.getSongs().isEmpty()) {
                Toast.makeText(this, "Нет MIDI — загрузи в приложении", Toast.LENGTH_SHORT).show()
            } else {
                MidiFilePlayer.prev()
                refreshMidiTransport()
            }
        }
        btnMidiPlay?.setOnClickListener {
            if (MidiFilePlayer.getSongs().isEmpty()) {
                Toast.makeText(this, "Нет MIDI — загрузи в приложении", Toast.LENGTH_SHORT).show()
            } else {
                MidiFilePlayer.togglePlayPause()
                refreshMidiTransport()
            }
        }
        floatView!!.findViewById<TextView>(R.id.btnMidiReset).setOnClickListener {
            MidiFilePlayer.reset()
            refreshMidiTransport()
        }
        floatView!!.findViewById<TextView>(R.id.btnMidiNext).setOnClickListener {
            if (MidiFilePlayer.getSongs().isEmpty()) {
                Toast.makeText(this, "Нет MIDI — загрузи в приложении", Toast.LENGTH_SHORT).show()
            } else {
                MidiFilePlayer.next()
                refreshMidiTransport()
            }
        }

        refreshStatusIdle()
        refreshPresetLabel()
        refreshDelayLabel()
        refreshMidiTransport()

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 180
        }

        floatView!!.findViewById<View>(R.id.floatHeader).setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params!!.x
                    initialY = params!!.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params!!.x = initialX + (event.rawX - initialTouchX).toInt()
                    params!!.y = initialY + (event.rawY - initialTouchY).toInt()
                    windowManager?.updateViewLayout(floatView, params)
                    true
                }
                else -> false
            }
        }

        windowManager?.addView(floatView, params)
    }

    // ---------- Delay ----------

    private fun changeDelay(dir: Int) {
        // steps: 0, 5, 8, 10, 12, 15, 18, 20, 25, 30, 40, 50, 75, 100
        val steps = intArrayOf(0, 5, 8, 10, 12, 15, 18, 20, 25, 30, 40, 50, 75, 100)
        val cur = ClickAccessibilityService.getDelayMs(this).toInt()
        val idx = steps.indexOfFirst { it >= cur }.let { if (it < 0) steps.lastIndex else it }
        val next = (idx + dir).coerceIn(0, steps.lastIndex)
        ClickAccessibilityService.setDelayMs(this, steps[next])
        refreshDelayLabel()
        Toast.makeText(
            this,
            if (steps[next] == 0) "Задержка 0 = multi (быстро, может терять)"
            else "Задержка ${steps[next]} ms (последовательный аккорд)",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun refreshDelayLabel() {
        val ms = ClickAccessibilityService.getDelayMs(this).toInt()
        tvDelayMs?.text = "$ms ms"
    }

    // ---------- Show points ----------

    private fun showPointsPreview() {
        if (PointsPreviewService.isRunning()) {
            stopService(Intent(this, PointsPreviewService::class.java))
            return
        }
        try {
            startService(Intent(this, PointsPreviewService::class.java))
            Toast.makeText(this, "Серый оверлей с точками (тап — закрыть)", Toast.LENGTH_SHORT).show()
        } catch (t: Throwable) {
            Toast.makeText(this, "Нужен overlay", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- White keys fill ----------

    private fun toggleWhiteFill() {
        if (whiteStep != 0) {
            cancelWhiteFill()
            Toast.makeText(this, "Заполнение белых отменено", Toast.LENGTH_SHORT).show()
            return
        }
        if (blackStep != 0) cancelBlackFill()
        if (isCalibrating) stopCalibration()
        if (PresetManager.mode != "click") {
            PresetManager.setMode("click")
            Toast.makeText(this, "CLICK для заполнения", Toast.LENGTH_SHORT).show()
        }
        if (PresetManager.getActivePreset() == null) {
            PresetManager.ensureDefault()
        }
        whiteStep = 1
        isWhiteFillActive = true
        whiteLeftNote = -1
        whiteRightNote = -1
        btnWhiteFill?.setBackgroundColor(0xFFC62828.toInt())
        floatStatus?.text = "⬜ левая белая\nжди MIDI…"
        floatStatus?.setTextColor(0xFF80CBC4.toInt())
        Toast.makeText(
            this,
            "1) Нажми самую ЛЕВУЮ белую на MIDI\n2) Тапни по экрану\n3) Правую белую + тап",
            Toast.LENGTH_LONG
        ).show()
    }

    private fun cancelWhiteFill() {
        whiteStep = 0
        isWhiteFillActive = isWhiteFillActive && blackStep != 0
        if (blackStep == 0) isWhiteFillActive = false
        btnWhiteFill?.setBackgroundColor(0xFF00695C.toInt())
        if (blackStep == 0) refreshStatusIdle()
    }

    private fun onWhiteMidi(note: Int) {
        when (whiteStep) {
            1 -> {
                if (!MainActivity.isWhiteKey(note)) {
                    Toast.makeText(this, "Это не белая клавиша", Toast.LENGTH_SHORT).show()
                    return
                }
                whiteLeftNote = note
                whiteStep = 2
                floatStatus?.text = "⬜ ${MainActivity.noteNumberToName(note).substringBefore(" (")}\nтапни экран"
                floatStatus?.setTextColor(0xFF00E676.toInt())
                startFillPicker()
            }
            3 -> {
                if (!MainActivity.isWhiteKey(note)) {
                    Toast.makeText(this, "Это не белая клавиша", Toast.LENGTH_SHORT).show()
                    return
                }
                if (note == whiteLeftNote) {
                    Toast.makeText(this, "Выбери другую (правую) клавишу", Toast.LENGTH_SHORT).show()
                    return
                }
                whiteRightNote = note
                whiteStep = 4
                floatStatus?.text = "⬜ ${MainActivity.noteNumberToName(note).substringBefore(" (")}\nтапни экран"
                floatStatus?.setTextColor(0xFF00E676.toInt())
                startFillPicker()
            }
        }
    }

    private fun startFillPicker() {
        try {
            startService(Intent(this, WhiteTapPickerService::class.java))
        } catch (t: Throwable) {
            Log.e(TAG, "fill picker", t)
            Toast.makeText(this, "Нужен overlay", Toast.LENGTH_SHORT).show()
            cancelWhiteFill()
            cancelBlackFill()
        }
    }

    private fun onFillTap(x: Float, y: Float) {
        // White path
        when (whiteStep) {
            2 -> {
                whiteLeftX = x
                whiteLeftY = y
                whiteStep = 3
                floatStatus?.text = "⬜ правая белая\nжди MIDI…"
                floatStatus?.setTextColor(0xFF80CBC4.toInt())
                Toast.makeText(this, "Теперь правая белая на MIDI", Toast.LENGTH_SHORT).show()
                return
            }
            4 -> {
                finishWhiteFill(x, y)
                return
            }
        }
        // Black path
        if (blackStep in 1..BLACK_PATTERN_COUNT && blackWaitTap) {
            blackPattern.add(blackPendingNote to (x to y))
            blackWaitTap = false
            if (blackPattern.size >= BLACK_PATTERN_COUNT) {
                blackStep = BLACK_PATTERN_COUNT + 1
                floatStatus?.text = "⬛ правая чёрная\nжди MIDI…"
                floatStatus?.setTextColor(0xFFCE93D8.toInt())
                Toast.makeText(this, "Теперь самую ПРАВУЮ чёрную на MIDI", Toast.LENGTH_SHORT).show()
            } else {
                blackStep = blackPattern.size + 1
                floatStatus?.text = "⬛ чёрная ${blackPattern.size + 1}/$BLACK_PATTERN_COUNT\nжди MIDI…"
                floatStatus?.setTextColor(0xFFCE93D8.toInt())
            }
        }
    }

    private fun finishWhiteFill(rightX: Float, rightY: Float) {
        val left = whiteLeftNote
        val right = whiteRightNote
        if (left < 0 || right < 0) {
            cancelWhiteFill()
            return
        }
        val lowNote = minOf(left, right)
        val highNote = maxOf(left, right)
        val x0: Float
        val y0: Float
        val x1: Float
        val y1: Float
        if (left <= right) {
            x0 = whiteLeftX; y0 = whiteLeftY; x1 = rightX; y1 = rightY
        } else {
            x0 = rightX; y0 = rightY; x1 = whiteLeftX; y1 = whiteLeftY
        }

        val whitesSorted = MainActivity.whiteKeysBetween(lowNote, highNote)
        val n = whitesSorted.size
        if (n < 2) {
            Toast.makeText(this, "Нужно ≥ 2 белых клавиши", Toast.LENGTH_SHORT).show()
            cancelWhiteFill()
            return
        }
        for (i in whitesSorted.indices) {
            val t = if (n == 1) 0f else i.toFloat() / (n - 1)
            val px = x0 + (x1 - x0) * t
            val py = y0 + (y1 - y0) * t
            PresetManager.setPoint(whitesSorted[i], px, py)
        }
        sendBroadcast(
            Intent("com.miditoqwertyMyx.android.PRESET_UPDATED").setPackage(packageName)
        )
        cancelWhiteFill()
        refreshPresetLabel()
        Toast.makeText(
            this,
            "Заполнено ${whitesSorted.size} белых (${whitesSorted.first()}…${whitesSorted.last()})",
            Toast.LENGTH_LONG
        ).show()
    }

    // ---------- Black keys fill ----------

    private fun toggleBlackFill() {
        if (blackStep != 0) {
            cancelBlackFill()
            Toast.makeText(this, "Заполнение чёрных отменено", Toast.LENGTH_SHORT).show()
            return
        }
        if (whiteStep != 0) cancelWhiteFill()
        if (isCalibrating) stopCalibration()
        if (PresetManager.mode != "click") {
            PresetManager.setMode("click")
            Toast.makeText(this, "CLICK для заполнения", Toast.LENGTH_SHORT).show()
        }
        if (PresetManager.getActivePreset() == null) {
            PresetManager.ensureDefault()
        }
        blackStep = 1
        blackWaitTap = false
        blackPendingNote = -1
        blackPattern.clear()
        blackRightNote = -1
        isWhiteFillActive = true
        btnBlackFill?.setBackgroundColor(0xFFC62828.toInt())
        floatStatus?.text = "⬛ чёрная 1/$BLACK_PATTERN_COUNT\nжди MIDI…"
        floatStatus?.setTextColor(0xFFCE93D8.toInt())
        Toast.makeText(
            this,
            "Чёрные: нажми 1-ю чёрную MIDI → тап экрана → 2-ю → тап … (всего $BLACK_PATTERN_COUNT), затем правую чёрную",
            Toast.LENGTH_LONG
        ).show()
    }

    private fun cancelBlackFill() {
        blackStep = 0
        blackWaitTap = false
        blackPendingNote = -1
        blackPattern.clear()
        blackRightNote = -1
        isWhiteFillActive = whiteStep != 0
        btnBlackFill?.setBackgroundColor(0xFF4A148C.toInt())
        if (whiteStep == 0) refreshStatusIdle()
    }

    private fun onBlackMidi(note: Int) {
        if (!MainActivity.isBlackKey(note)) {
            Toast.makeText(this, "Это не чёрная клавиша", Toast.LENGTH_SHORT).show()
            return
        }
        if (blackWaitTap) {
            Toast.makeText(this, "Сначала тапни по экрану", Toast.LENGTH_SHORT).show()
            return
        }

        when {
            blackStep in 1..BLACK_PATTERN_COUNT -> {
                // reject duplicate in pattern
                if (blackPattern.any { it.first == note }) {
                    Toast.makeText(this, "Эта нота уже записана", Toast.LENGTH_SHORT).show()
                    return
                }
                blackPendingNote = note
                blackWaitTap = true
                floatStatus?.text =
                    "⬛ ${MainActivity.noteNumberToName(note).substringBefore(" (")}\nтапни экран (${blackPattern.size + 1}/$BLACK_PATTERN_COUNT)"
                floatStatus?.setTextColor(0xFF00E676.toInt())
                startFillPicker()
            }
            blackStep == BLACK_PATTERN_COUNT + 1 -> {
                // right boundary
                if (blackPattern.isEmpty()) {
                    cancelBlackFill()
                    return
                }
                val leftNote = blackPattern.minOf { it.first }
                if (note <= leftNote) {
                    Toast.makeText(this, "Правая должна быть правее паттерна", Toast.LENGTH_SHORT).show()
                    return
                }
                blackRightNote = note
                finishBlackFill()
            }
        }
    }

    /**
     * Tile the captured 6-point pattern across all black keys from
     * leftmost pattern note to right boundary.
     *
     * Uses measured X deltas of the pattern, cycling them, and average Y.
     */
    private fun finishBlackFill() {
        if (blackPattern.size < 2 || blackRightNote < 0) {
            Toast.makeText(this, "Мало точек паттерна", Toast.LENGTH_SHORT).show()
            cancelBlackFill()
            return
        }

        // Sort pattern by note ascending
        val sorted = blackPattern.sortedBy { it.first }
        val leftNote = sorted.first().first
        val rightNote = blackRightNote
        val allBlacks = MainActivity.blackKeysBetween(leftNote, rightNote)
        if (allBlacks.size < 2) {
            Toast.makeText(this, "Нужно ≥ 2 чёрных в диапазоне", Toast.LENGTH_SHORT).show()
            cancelBlackFill()
            return
        }

        // Pattern X positions and deltas
        val patternXs = sorted.map { it.second.first }
        val patternYs = sorted.map { it.second.second }
        val avgY = patternYs.average().toFloat()

        // Deltas between consecutive pattern points; last delta = average of others
        // (or gap from last to "next group" approximated)
        val deltas = ArrayList<Float>()
        for (i in 0 until patternXs.size - 1) {
            deltas.add(patternXs[i + 1] - patternXs[i])
        }
        if (deltas.isEmpty()) deltas.add(20f)
        // Optional: add a slightly larger gap after the group (octave-ish)
        val meanDelta = deltas.average().toFloat()
        // Keep only measured internal deltas; cycle them

        var x = patternXs.first()
        var di = 0
        for (i in allBlacks.indices) {
            val note = allBlacks[i]
            val py = if (i < patternYs.size) patternYs[i] else avgY
            PresetManager.setPoint(note, x, py)
            if (i < allBlacks.lastIndex) {
                val d = deltas[di % deltas.size]
                x += d
                di++
                // When we complete a full pattern cycle, optionally stretch
                // remaining distance toward right if user gave far right boundary
            }
        }

        // If the last assigned X is far from a reasonable right, re-scale linearly
        // so the whole range fits left→right better when pattern count != black count
        if (allBlacks.size != sorted.size) {
            val xLeft = patternXs.first()
            // Estimate right X: continue deltas until last black
            var estRight = patternXs.first()
            var edi = 0
            for (i in 0 until allBlacks.size - 1) {
                estRight += deltas[edi % deltas.size]
                edi++
            }
            // Prefer pure tiling; if estRight is nonsense, fall back to linear
            // (no screen right tap — we only have MIDI right). Keep tiling.
        }

        sendBroadcast(
            Intent("com.miditoqwertyMyx.android.PRESET_UPDATED").setPackage(packageName)
        )
        val filled = allBlacks.size
        cancelBlackFill()
        refreshPresetLabel()
        Toast.makeText(
            this,
            "Заполнено $filled чёрных (${allBlacks.first()}…${allBlacks.last()}) по паттерну ${sorted.size}",
            Toast.LENGTH_LONG
        ).show()
    }

    // ---------- Calibration ----------

    private fun toggleCalibration() {
        if (isCalibrating) {
            stopCalibration()
            Toast.makeText(this, "Калибровка стоп", Toast.LENGTH_SHORT).show()
        } else {
            if (whiteStep != 0) cancelWhiteFill()
            if (blackStep != 0) cancelBlackFill()
            if (PresetManager.mode != "click") {
                PresetManager.setMode("click")
                Toast.makeText(this, "CLICK для калибровки", Toast.LENGTH_SHORT).show()
            }
            if (PresetManager.getActivePreset() == null) {
                PresetManager.ensureDefault()
            }
            isCalibrating = true
            editOneWaiting = false
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putBoolean("calibrating", true)
                .putBoolean("edit_one", false)
                .apply()
            btnStart?.text = "⏹"
            btnStart?.setBackgroundColor(0xFFC62828.toInt())
            floatStatus?.text = "● жди ноту…"
            floatStatus?.setTextColor(0xFFFFD54F.toInt())
            Toast.makeText(
                this,
                "Нота на MIDI → тап по экрану → следующая",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun stopCalibration() {
        isCalibrating = false
        editOneWaiting = false
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putBoolean("calibrating", false)
            .putBoolean("edit_one", false)
            .apply()
        btnStart?.text = "▶"
        btnStart?.setBackgroundColor(0xFF2E7D32.toInt())
        if (whiteStep == 0 && blackStep == 0) refreshStatusIdle()
    }

    private fun onMidiNote(note: Int) {
        if (whiteStep == 1 || whiteStep == 3) {
            onWhiteMidi(note)
            return
        }
        if (blackStep != 0) {
            onBlackMidi(note)
            return
        }
        if (!isCalibrating && !editOneWaiting) return
        if (CoordinatePickerService.isRunning() || WhiteTapPickerService.isRunning()) return

        val label = MainActivity.noteNumberToName(note)
        floatStatus?.text = "● $label\nтапни"
        floatStatus?.setTextColor(0xFF00E676.toInt())

        if (editOneWaiting) {
            editOneWaiting = false
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putBoolean("edit_one", false).apply()
        }

        try {
            startService(
                Intent(this, CoordinatePickerService::class.java)
                    .putExtra(CoordinatePickerService.EXTRA_NOTE, note)
            )
        } catch (t: Throwable) {
            Log.e(TAG, "picker", t)
            Toast.makeText(this, "Нужен overlay", Toast.LENGTH_SHORT).show()
        }
    }

    private fun toggleSettings() {
        settingsOpen = !settingsOpen
        settingsPanel?.visibility = if (settingsOpen) View.VISIBLE else View.GONE
        if (settingsOpen) {
            refreshPresetLabel()
            refreshDelayLabel()
        }
    }

    private fun refreshPresetLabel() {
        val p = PresetManager.getActivePreset()
        val n = p?.points?.size ?: 0
        tvPresetName?.text = "${p?.name ?: "—"} · $n т."
    }

    private fun refreshStatusIdle() {
        val m = PresetManager.mode
        val delay = ClickAccessibilityService.getDelayMs(this).toInt()
        floatStatus?.text = if (m == "click") "● CLICK · ${delay}ms" else "● KEY"
        floatStatus?.setTextColor(if (m == "click") 0xFF2196F3.toInt() else 0xFF00E676.toInt())
    }

    private fun refreshMidiTransport() {
        val songs = MidiFilePlayer.getSongs()
        val song = MidiFilePlayer.currentSong()
        if (songs.isEmpty()) {
            tvMidiSong?.text = "MIDI: —"
            btnMidiPlay?.text = "▶▮"
            return
        }
        val idx = MidiFilePlayer.currentIndex() + 1
        val name = song?.name ?: "?"
        val state = when {
            MidiFilePlayer.isPlaying() -> "▶"
            MidiFilePlayer.isPaused() -> "▮▮"
            else -> "■"
        }
        tvMidiSong?.text = "$state $idx/${songs.size} $name"
        btnMidiPlay?.text = if (MidiFilePlayer.isPlaying()) "▮▮" else "▶"
    }

    private fun cyclePreset(dir: Int) {
        val list = PresetManager.getPresets()
        if (list.isEmpty()) return
        val cur = PresetManager.activePresetId
        val idx = list.indexOfFirst { it.id == cur }.let { if (it < 0) 0 else it }
        val next = (idx + dir + list.size) % list.size
        PresetManager.setActivePreset(list[next].id)
        refreshPresetLabel()
        Toast.makeText(this, list[next].name, Toast.LENGTH_SHORT).show()
    }

    private fun addPreset() {
        val n = PresetManager.getPresets().size + 1
        val p = ClickPreset.createEmpty("Preset $n")
        PresetManager.addPreset(p)
        PresetManager.setActivePreset(p.id)
        refreshPresetLabel()
        Toast.makeText(this, "+ ${p.name}", Toast.LENGTH_SHORT).show()
    }

    private fun delPreset() {
        val id = PresetManager.activePresetId ?: return
        if (PresetManager.getPresets().size <= 1) {
            Toast.makeText(this, "Последний пресет", Toast.LENGTH_SHORT).show()
            return
        }
        PresetManager.deletePreset(id)
        refreshPresetLabel()
        Toast.makeText(this, "Удалено", Toast.LENGTH_SHORT).show()
    }

    private fun startEditOne() {
        if (PresetManager.getActivePreset() == null) {
            Toast.makeText(this, "Нет пресета", Toast.LENGTH_SHORT).show()
            return
        }
        editOneWaiting = true
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putBoolean("edit_one", true).apply()
        floatStatus?.text = "✎ жди 1 ноту…"
        floatStatus?.setTextColor(0xFFE040FB.toInt())
        if (settingsOpen) toggleSettings()
        Toast.makeText(this, "Одна MIDI-нота → тап по точке", Toast.LENGTH_LONG).show()
    }

    private fun toggleMode() {
        val next = if (PresetManager.mode == "click") "key" else "click"
        PresetManager.setMode(next)
        if (!isCalibrating && whiteStep == 0 && blackStep == 0) refreshStatusIdle()
        Toast.makeText(
            this,
            if (next == "click") "Mode: CLICK" else "Mode: KEY",
            Toast.LENGTH_SHORT
        ).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        stopCalibration()
        cancelWhiteFill()
        cancelBlackFill()
        if (receiverRegistered) {
            try { unregisterReceiver(receiver) } catch (_: Throwable) {}
            receiverRegistered = false
        }
        try { windowManager?.removeView(floatView) } catch (_: Exception) {}
        floatView = null
        stopForeground(true)
    }
}

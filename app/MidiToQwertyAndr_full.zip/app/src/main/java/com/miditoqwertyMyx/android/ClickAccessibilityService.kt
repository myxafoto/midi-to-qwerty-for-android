package com.miditoqwertyMyx.android

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

/**
 * Accessibility service for CLICK mode (screen taps).
 *
 * Hybrid strategy:
 *  - Enqueue every tap.
 *  - Batch near-simultaneous notes (chord window).
 *  - If user delay > 0 OR batch size == 1 → always sequential single taps
 *    with the configured gap (reliable, no drops).
 *  - If delay == 0 and batch > 1 → try multi-stroke first; on cancel/fail
 *    fall back to sequential.
 *  - GestureResultCallback gives real completion feedback.
 */
class ClickAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "ClickA11y"
        private const val PREFS = "float_calib"
        private const val KEY_DELAY = "click_delay_ms"

        private const val MAX_STROKES = 8
        private const val CHORD_WINDOW_MS = 18L
        private const val BATCH_GAP_MS = 12L
        private const val DEFAULT_DELAY_MS = 12L
        private const val TAP_DURATION_MS = 32L
        private const val MAX_RETRY = 2

        @Volatile
        var instance: ClickAccessibilityService? = null
            private set

        fun isRunning(): Boolean = instance != null

        fun performClick(x: Float, y: Float): Boolean {
            val svc = instance ?: return false
            return svc.enqueueTap(x, y)
        }

        @Volatile
        var lastResult: String = "idle"
            private set

        fun getDelayMs(ctx: Context): Long {
            val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            return p.getInt(KEY_DELAY, DEFAULT_DELAY_MS.toInt()).toLong().coerceIn(0L, 200L)
        }

        fun setDelayMs(ctx: Context, ms: Int) {
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putInt(KEY_DELAY, ms.coerceIn(0, 200))
                .apply()
        }
    }

    private data class Tap(
        val x: Float,
        val y: Float,
        val atMs: Long,
        var retries: Int = 0
    )

    private val queue = ConcurrentLinkedQueue<Tap>()
    private val draining = AtomicBoolean(false)
    private val handler = Handler(Looper.getMainLooper())

    private val completedCount = AtomicInteger(0)
    private val cancelledCount = AtomicInteger(0)
    private val sequentialCount = AtomicInteger(0)

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        PresetManager.init(this)
        Log.d(TAG, "Accessibility connected, delay=${getDelayMs(this)}ms")
        lastResult = "connected"
        sendBroadcast(
            Intent("com.miditoqwertyMyx.android.A11Y_STATUS")
                .setPackage(packageName)
                .putExtra("running", true)
        )
    }

    override fun onDestroy() {
        instance = null
        queue.clear()
        handler.removeCallbacksAndMessages(null)
        lastResult = "destroyed"
        sendBroadcast(
            Intent("com.miditoqwertyMyx.android.A11Y_STATUS")
                .setPackage(packageName)
                .putExtra("running", false)
        )
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun enqueueTap(x: Float, y: Float): Boolean {
        queue.offer(Tap(x, y, System.currentTimeMillis()))
        scheduleDrain(0L)
        return true
    }

    private fun scheduleDrain(delayMs: Long) {
        handler.postDelayed({ drain() }, delayMs)
    }

    private fun currentSeqGap(): Long = getDelayMs(this).coerceAtLeast(0L)

    private fun drain() {
        if (!draining.compareAndSet(false, true)) return
        try {
            val first = queue.poll() ?: run {
                draining.set(false)
                return
            }
            val batch = ArrayList<Tap>(MAX_STROKES)
            batch.add(first)
            val t0 = first.atMs

            while (batch.size < MAX_STROKES) {
                val next = queue.peek() ?: break
                if (next.atMs - t0 > CHORD_WINDOW_MS) break
                queue.poll()
                batch.add(next)
            }

            if (batch.size == 1) {
                while (batch.size < MAX_STROKES) {
                    val next = queue.poll() ?: break
                    batch.add(next)
                }
            }

            Log.d(TAG, "drain batch=${batch.size} queueLeft=${queue.size} delay=${currentSeqGap()}")
            dispatchBatch(batch)
        } catch (t: Throwable) {
            Log.e(TAG, "drain", t)
            draining.set(false)
            if (queue.isNotEmpty()) scheduleDrain(BATCH_GAP_MS)
        }
    }

    private fun dispatchBatch(batch: List<Tap>) {
        if (batch.isEmpty()) {
            draining.set(false)
            return
        }

        val gap = currentSeqGap()

        // delay > 0 or single note → sequential (reliable chord: do → wait → re → wait → mi)
        if (gap > 0L || batch.size == 1) {
            playSequential(batch, gap.coerceAtLeast(8L))
            return
        }

        // delay == 0 and multi: try simultaneous multi-stroke
        try {
            val builder = GestureDescription.Builder()
            for (i in batch.indices) {
                val t = batch[i]
                val path = Path().apply { moveTo(t.x, t.y) }
                val start = (i * 2).toLong()
                builder.addStroke(
                    GestureDescription.StrokeDescription(path, start, TAP_DURATION_MS)
                )
            }
            val gesture = builder.build()

            val ok = dispatchGesture(gesture, object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    completedCount.addAndGet(batch.size)
                    lastResult = "multi OK size=${batch.size}"
                    Log.d(TAG, "multi COMPLETED size=${batch.size}")
                    finishBatch()
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    cancelledCount.addAndGet(batch.size)
                    lastResult = "multi CANCEL → seq"
                    Log.w(TAG, "multi CANCELLED size=${batch.size} → sequential")
                    batch.asReversed().forEach { queue.offer(it) }
                    draining.set(false)
                    scheduleDrain(0L)
                }
            }, null)

            if (!ok) {
                Log.w(TAG, "dispatchGesture=false → sequential")
                lastResult = "dispatch false → seq"
                playSequential(batch, 10L)
            }
        } catch (t: Throwable) {
            Log.e(TAG, "dispatchBatch", t)
            lastResult = "exception → seq"
            playSequential(batch, 10L)
        }
    }

    private fun playSequential(batch: List<Tap>, gapMs: Long) {
        if (batch.isEmpty()) {
            finishBatch()
            return
        }
        sequentialCount.addAndGet(batch.size)
        playSequentialIndex(batch, 0, gapMs)
    }

    private fun playSequentialIndex(batch: List<Tap>, index: Int, gapMs: Long) {
        if (index >= batch.size) {
            finishBatch()
            return
        }

        val t = batch[index]
        val path = Path().apply { moveTo(t.x, t.y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, TAP_DURATION_MS)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        val ok = try {
            dispatchGesture(gesture, object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    completedCount.incrementAndGet()
                    lastResult = "seq OK ${index + 1}/${batch.size}"
                    handler.postDelayed({
                        playSequentialIndex(batch, index + 1, gapMs)
                    }, gapMs)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    cancelledCount.incrementAndGet()
                    Log.w(TAG, "seq CANCEL at $index retries=${t.retries}")
                    if (t.retries < MAX_RETRY) {
                        t.retries++
                        handler.postDelayed({
                            playSequentialIndex(batch, index, gapMs)
                        }, gapMs)
                    } else {
                        lastResult = "seq DROP ${index + 1}/${batch.size}"
                        Log.e(TAG, "seq DROP after $MAX_RETRY retries")
                        handler.postDelayed({
                            playSequentialIndex(batch, index + 1, gapMs)
                        }, gapMs)
                    }
                }
            }, null)
        } catch (th: Throwable) {
            Log.e(TAG, "seq dispatch", th)
            false
        }

        if (!ok) {
            Log.w(TAG, "seq dispatchGesture=false at $index")
            if (t.retries < MAX_RETRY) {
                t.retries++
                handler.postDelayed({
                    playSequentialIndex(batch, index, gapMs)
                }, gapMs)
            } else {
                handler.postDelayed({
                    playSequentialIndex(batch, index + 1, gapMs)
                }, gapMs)
            }
        }
    }

    private fun finishBatch() {
        draining.set(false)
        if (queue.isNotEmpty()) {
            scheduleDrain(BATCH_GAP_MS)
        } else {
            Log.d(
                TAG,
                "queue empty. stats ok=${completedCount.get()} cancel=${cancelledCount.get()} seq=${sequentialCount.get()}"
            )
        }
    }
}

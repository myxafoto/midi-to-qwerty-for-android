package com.miditoqwertyMyx.android

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.util.Log
import android.view.accessibility.AccessibilityEvent

/**
 * Accessibility service used only for CLICK mode (screen taps).
 * KEY mode still goes through Shizuku/UHID and does not need this service.
 */
class ClickAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "ClickA11y"
        @Volatile
        var instance: ClickAccessibilityService? = null
            private set

        fun isRunning(): Boolean = instance != null

        /** Tap at (x,y) if service is connected. */
        fun performClick(x: Float, y: Float): Boolean {
            val svc = instance ?: return false
            return svc.tap(x, y)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        PresetManager.init(this)
        Log.d(TAG, "Accessibility connected")
        sendBroadcast(Intent("com.miditoqwertyMyx.android.A11Y_STATUS")
            .setPackage(packageName)
            .putExtra("running", true))
    }

    override fun onDestroy() {
        instance = null
        sendBroadcast(Intent("com.miditoqwertyMyx.android.A11Y_STATUS")
            .setPackage(packageName)
            .putExtra("running", false))
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun tap(x: Float, y: Float): Boolean {
        return try {
            val path = Path().apply { moveTo(x, y) }
            val stroke = GestureDescription.StrokeDescription(path, 0, 50)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()
            val ok = dispatchGesture(gesture, null, null)
            if (!ok) Log.w(TAG, "dispatchGesture false at ($x,$y)")
            ok
        } catch (t: Throwable) {
            Log.e(TAG, "tap failed", t)
            false
        }
    }
}

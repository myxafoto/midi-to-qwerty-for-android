package com.miditoqwertyMyx.android

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import rikka.shizuku.Shizuku
import rikka.shizuku.Shizuku.OnRequestPermissionResultListener

class SettingsActivity : AppCompatActivity() {

    companion object {
        private const val REQUEST_CODE_SHIZUKU = 2001
    }

    private lateinit var modeStatus: TextView
    private lateinit var shizukuStatus: TextView
    private lateinit var presetStatus: TextView
    private lateinit var btnPipette: Button

    private var pickNoteWaiting = false
    private val mainHandler = Handler(Looper.getMainLooper())

    private val shizukuPermissionListener =
        OnRequestPermissionResultListener { requestCode, _ ->
            if (requestCode == REQUEST_CODE_SHIZUKU) updateShizukuStatus()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        modeStatus = findViewById(R.id.modeStatus)
        shizukuStatus = findViewById(R.id.shizukuStatus)
        presetStatus = findViewById(R.id.presetStatus)
        btnPipette = findViewById(R.id.btnPipette)

        PresetManager.init(this)
        PresetManager.ensureDefault()

        findViewById<Button>(R.id.btnToggleMode).setOnClickListener { toggleMode() }
        findViewById<Button>(R.id.btnShizuku).setOnClickListener { checkAndRequestShizuku() }
        findViewById<Button>(R.id.btnPcMode).setOnClickListener { enablePcMode() }
        findViewById<Button>(R.id.btnPresetPrev).setOnClickListener { cyclePreset(-1) }
        findViewById<Button>(R.id.btnPresetNext).setOnClickListener { cyclePreset(+1) }
        findViewById<Button>(R.id.btnPresetAdd).setOnClickListener { addPreset() }
        findViewById<Button>(R.id.btnPresetDel).setOnClickListener { deletePreset() }
        btnPipette.setOnClickListener { startPipette() }
        findViewById<Button>(R.id.btnBack).setOnClickListener { finish() }

        updateModeUi()
        updateShizukuStatus()
        updatePresetUi()
    }

    override fun onResume() {
        super.onResume()
        updateModeUi()
        updateShizukuStatus()
        updatePresetUi()
    }

    override fun onDestroy() {
        super.onDestroy()
        try { Shizuku.removeRequestPermissionResultListener(shizukuPermissionListener) } catch (_: Exception) {}
    }

    /** Called from MainActivity MIDI path when pipette is waiting. */
    fun onMidiForPipette(noteNumber: Int): Boolean {
        if (!pickNoteWaiting) return false
        pickNoteWaiting = false
        mainHandler.post {
            btnPipette.text = "Пипетка: MIDI → тап (1 точка)"
            startCoordinatePicker(noteNumber)
        }
        return true
    }

    private fun updateModeUi() {
        val m = PresetManager.mode
        modeStatus.text = if (m == "click") "Mode: CLICK (тапы)" else "Mode: KEY (клавиши)"
        modeStatus.setTextColor(if (m == "click") 0xFF2196F3.toInt() else 0xFF00E676.toInt())
    }

    private fun toggleMode() {
        val next = if (PresetManager.mode == "click") "key" else "click"
        if (next == "click") {
            val svc = android.content.ComponentName(this, ClickAccessibilityService::class.java).flattenToString()
            val enabled = Settings.Secure.getString(
                contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: ""
            if (!enabled.contains(svc) && !ClickAccessibilityService.isRunning()) {
                Toast.makeText(this, "Сначала включи Accessibility на главном экране", Toast.LENGTH_LONG).show()
                return
            }
        }
        PresetManager.setMode(next)
        updateModeUi()
        Toast.makeText(this, if (next == "click") "Режим CLICK" else "Режим KEY", Toast.LENGTH_SHORT).show()
    }

    private fun updateShizukuStatus() {
        try {
            if (!Shizuku.pingBinder()) {
                shizukuStatus.text = "Shizuku: НЕ ЗАПУЩЕН"
                shizukuStatus.setTextColor(0xFFFF9800.toInt())
                return
            }
            val granted = Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED
            if (granted) {
                val inj = KeyInjector.init()
                UhidClient.start(this)
                shizukuStatus.text = if (inj) "Shizuku ✓ · inject OK" else "Shizuku ✓ · inject fail"
                shizukuStatus.setTextColor(0xFF4CAF50.toInt())
                mainHandler.postDelayed({
                    if (UhidClient.isUhidActive()) {
                        shizukuStatus.text = "Shizuku ✓ · UHID keyboard/mouse active"
                    }
                }, 1000)
            } else {
                shizukuStatus.text = "Shizuku: нет разрешения"
                shizukuStatus.setTextColor(0xFFF44336.toInt())
            }
        } catch (e: Exception) {
            shizukuStatus.text = "Shizuku: ошибка — ${e.message}"
            shizukuStatus.setTextColor(0xFFF44336.toInt())
        }
    }

    private fun checkAndRequestShizuku() {
        try {
            if (!Shizuku.pingBinder()) {
                Toast.makeText(this, "Shizuku не запущен", Toast.LENGTH_LONG).show()
                updateShizukuStatus()
                return
            }
            if (Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Разрешение уже есть", Toast.LENGTH_SHORT).show()
                updateShizukuStatus()
                return
            }
            Shizuku.addRequestPermissionResultListener(shizukuPermissionListener)
            Shizuku.requestPermission(REQUEST_CODE_SHIZUKU)
        } catch (e: Exception) {
            Toast.makeText(this, "Ошибка Shizuku: ${e.message}", Toast.LENGTH_LONG).show()
            updateShizukuStatus()
        }
    }

    private fun enablePcMode() {
        if (!Shizuku.pingBinder()) {
            Toast.makeText(this, "Сначала запусти Shizuku", Toast.LENGTH_LONG).show()
            return
        }
        if (Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Выдай разрешение Shizuku", Toast.LENGTH_LONG).show()
            checkAndRequestShizuku()
            return
        }
        Toast.makeText(this, "Запуск uhid…", Toast.LENGTH_SHORT).show()
        val started = UhidClient.start(this)
        if (!started) {
            Toast.makeText(this, "Не удалось bind UserService", Toast.LENGTH_LONG).show()
            return
        }
        mainHandler.postDelayed({
            val uhidOk = UhidClient.isUhidActive()
            UhidClient.enablePcModeHint()
            KeyInjector.init()
            KeyInjector.enablePcModeHint()
            Toast.makeText(
                this,
                if (uhidOk) "UHID OK" else "UHID fail — остаётся inject",
                Toast.LENGTH_LONG
            ).show()
            updateShizukuStatus()
        }, 800)
    }

    private fun updatePresetUi() {
        val p = PresetManager.getActivePreset()
        val count = p?.points?.size ?: 0
        presetStatus.text = "Preset: ${p?.name ?: "—"} · точек: $count"
    }

    private fun cyclePreset(dir: Int) {
        val list = PresetManager.getPresets()
        if (list.isEmpty()) return
        val cur = PresetManager.activePresetId
        val idx = list.indexOfFirst { it.id == cur }.let { if (it < 0) 0 else it }
        val next = (idx + dir + list.size) % list.size
        PresetManager.setActivePreset(list[next].id)
        updatePresetUi()
        Toast.makeText(this, list[next].name, Toast.LENGTH_SHORT).show()
    }

    private fun addPreset() {
        val n = PresetManager.getPresets().size + 1
        val p = ClickPreset.createEmpty("Preset $n")
        PresetManager.addPreset(p)
        PresetManager.setActivePreset(p.id)
        updatePresetUi()
        Toast.makeText(this, "Добавлен ${p.name}", Toast.LENGTH_SHORT).show()
    }

    private fun deletePreset() {
        val id = PresetManager.activePresetId ?: return
        if (PresetManager.getPresets().size <= 1) {
            Toast.makeText(this, "Нельзя удалить последний пресет", Toast.LENGTH_SHORT).show()
            return
        }
        PresetManager.deletePreset(id)
        updatePresetUi()
        Toast.makeText(this, "Пресет удалён", Toast.LENGTH_SHORT).show()
    }

    private fun startPipette() {
        if (PresetManager.mode != "click") {
            Toast.makeText(this, "Сначала переключи в CLICK", Toast.LENGTH_SHORT).show()
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Нужен Overlay (главный экран)", Toast.LENGTH_SHORT).show()
            return
        }
        if (PresetManager.getActivePreset() == null) {
            Toast.makeText(this, "Нет активного пресета", Toast.LENGTH_SHORT).show()
            return
        }
        pickNoteWaiting = true
        MainActivity.pipetteWaiting = true
        btnPipette.text = "Жду ноту с MIDI…"
        Toast.makeText(this, "Нажми клавишу на MIDI, затем тапни по экрану", Toast.LENGTH_LONG).show()
    }

    private fun startCoordinatePicker(note: Int) {
        try {
            startService(
                Intent(this, CoordinatePickerService::class.java)
                    .putExtra(CoordinatePickerService.EXTRA_NOTE, note)
            )
        } catch (t: Throwable) {
            Toast.makeText(this, "Не удалось запустить пипетку", Toast.LENGTH_SHORT).show()
        }
    }
}

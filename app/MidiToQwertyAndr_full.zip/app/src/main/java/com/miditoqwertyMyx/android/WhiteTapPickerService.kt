package com.miditoqwertyMyx.android

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast

/**
 * One-shot full-screen tap for white-keys fill wizard.
 * Sends WHITE_TAP broadcast with x,y then stops.
 */
class WhiteTapPickerService : Service() {

    companion object {
        private const val TAG = "WhiteTapPicker"
        @Volatile private var running = false
        fun isRunning() = running
    }

    private var wm: WindowManager? = null
    private var overlay: FrameLayout? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (running) {
            stopSelf()
            return START_NOT_STICKY
        }
        showOverlay()
        running = true
        return START_NOT_STICKY
    }

    private fun showOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val layout = FrameLayout(this).apply {
            setBackgroundColor(0x55006655)
            isClickable = true
            isFocusable = true
        }

        val hint = TextView(this).apply {
            text = "Тапни по экрану\n(позиция клавиши)"
            setTextColor(Color.WHITE)
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        layout.addView(
            hint,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )

        val cancel = TextView(this).apply {
            text = "✕ ОТМЕНА"
            setTextColor(Color.RED)
            textSize = 14f
            setPadding(32, 24, 32, 24)
            setBackgroundColor(0xAA000000.toInt())
            setOnClickListener { hideAndStop() }
        }
        layout.addView(cancel, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            topMargin = 100
            rightMargin = 40
        })

        var armed = false
        layout.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN && armed) {
                val x = event.rawX
                val y = event.rawY
                sendBroadcast(
                    Intent("com.miditoqwertyMyx.android.WHITE_TAP")
                        .setPackage(packageName)
                        .putExtra("x", x)
                        .putExtra("y", y)
                )
                hideAndStop()
                true
            } else false
        }

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
            PixelFormat.TRANSLUCENT
        )

        try {
            wm?.addView(layout, params)
            overlay = layout
            layout.postDelayed({ armed = true }, 350)
        } catch (t: Throwable) {
            Log.e(TAG, "addView", t)
            Toast.makeText(this, "Нужно разрешение «поверх других окон»", Toast.LENGTH_LONG).show()
            stopSelf()
        }
    }

    private fun hideAndStop() {
        try { overlay?.let { wm?.removeView(it) } } catch (_: Throwable) {}
        overlay = null
        running = false
        stopSelf()
    }

    override fun onDestroy() {
        hideAndStop()
        super.onDestroy()
    }
}
